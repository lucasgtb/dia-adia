<?php
if(!$_SERVER[‘HTTPS’]) {
$protocolo = “https://”;
header( “Location: “.$protocolo.$_SERVER[‘SERVER_NAME’].$_SERVER[‘SCRIPT_NAME’]);
}
?>