<?php if($Sessao::retornaMensagem()){ ?>
  <script type="text/javascript">
     swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
 </script>
<?php } $Sessao::limpaMensagem(); ?>
<div class="container-fluid" style="margin-top: 60px;">
    <div class="row">
        <div class="col-md-1">

            <div class="mx-auto" id="calendar" style="position: fixed; bottom: 120px; left: 60px; z-index: 100000;">
            </div>
            <a href="http://<?php echo APP_HOST; ?>/calendario">
            <button class="btn btn-link text-light calendar-btn" id="calendar-btn" style="background: #415A77; position: fixed; bottom: 90px;"><i class="far fa-calendar-alt"></i></button></a>
        </div>
        <div class="col-md-8 mt-5">
            <div class="card" style="border: 1px solid #415A77;">
                <div class="card-header text-center text-white" style="background: #415A77; vertical-align: middle;">
                    <div class="row">
                        <div class="col-md-2 prev">
                            <i class="fas fa-chevron-left fa-2x"  style="float: left; cursor: pointer;"></i></i>
                        </div>
                        <div class="col-md-8 taskDate">
                            <h5 class="card-title"><?php echo utf8_encode(ucwords(strftime("%A-Feira, %d/%m/%Y"))); ?></h5>
                        </div>
                        <div class="col-md-2 next">
                            <i class="fas fa-chevron-right fa-2x" style="float: right; cursor: pointer;"></i>
                        </div>
                    </div>
                </div>
                <div class="card-body" id="tarefasDia">

                </div>
            </div>
        </div>
        <div class="col-md-3 px-2 py-3" style="height: calc(100vh - 60px); background: #8696A8;">
            <div class="col-md-12 text-center mb-5">
                <h5 class="text-light">Aniversariantes do Mês</h5>
            </div>
            <div class="col-md-12">
                <ul class="list-group text-white">
                    <?php
                    $date = date('d-m');
                    foreach($viewVar['listaAniversarioContato'] as $contato) {
                      $idade = date('Y') - $contato->getDataNascimento()->format('Y');

                    if($contato->getDataNascimento()->format('d-m') == $date){ ?>
                      <li class="list-group-item bg-transparent border-left-0 border-right-0"><i class="fas fa-birthday-cake"></i> <?php echo $contato->getDataNascimento()->format('d/m'); ?> - <?php echo $contato->getNome(); ?>  (<?php echo $idade ?> anos)</li>
                    <?php }else{   ?>
                      <li class="list-group-item bg-transparent border-left-0 border-right-0"><?php echo $contato->getDataNascimento()->format('d/m'); ?> - <?php echo $contato->getNome(); ?></li>
                    <?php
                    }
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>
</div>
