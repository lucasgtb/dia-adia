    </div>
    <footer class="footer">
        <div class="container">
            <p class="text-muted">
                    &copy; Team One | Todos os direitos reservados | 2019</p></font></a>
            </p>
        </div>
    </footer>

    <script src='http://<?php echo APP_HOST; ?>/public/fullcalendar/js/moment.min.js'></script>
    <script src='http://<?php echo APP_HOST; ?>/public/fullcalendar/js/jquery.min.js'></script>
    <script src='http://<?php echo APP_HOST; ?>/public/fullcalendar/js/fullcalendar.min.js'></script>
    <script src='http://<?php echo APP_HOST; ?>/public/fullcalendar/locale/pt-br.js'></script>

    <!-- script de tradução -->
    <!-- <script src='http://<?php echo APP_HOST; ?>/public/fullcalendar/lang/pt-br.js'></script> -->


    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="http://<?php echo APP_HOST; ?>/public/js/jquery.validate.min.js"type="text/javascript"></script>
    <script src="http://<?php echo APP_HOST; ?>/public/js/classie.js" type="text/javascript"></script>
    <script src="http://<?php echo APP_HOST; ?>/public/js/gnmenu.js" type="text/javascript"></script>
    <script type="text/javascript">
        new gnMenu(document.getElementById('gn-menu'));
    </script>
    <script src="http://<?php echo APP_HOST; ?>/public/js/browser.jquery.min.js"></script>
    <!-- <script src="http://<?php echo APP_HOST; ?>/public/js/jquery-ui-datepicker.min.js"></script> -->
    <!-- <script src="http://<?php echo APP_HOST; ?>/public/js/datepicker-pt-BR.js"></script> -->
    <!-- <script>
        $('#calendar').datepicker({
            inline: true,
            firstDay: 1,
            showOtherMonths: true,
            dayNamesMin: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Seg', 'Sab']
        });

    	$("#calendar-btn").on("click", function() {
            const classe = $("#calendar").children('.ui-datepicker').hasClass('show') ? true : false;
            if (classe) {
                $("#calendar").children('.ui-datepicker').removeClass('show');
            } else {
                $("#calendar").children('.ui-datepicker').addClass('show');
            }
        });
    </script>
    <script type="text/javascript">
  		// Este evendo é acionado após o carregamento da página
  		$(document).on('load', function() {
  			//Após a leitura da pagina o evento fadeOut do loader é acionado, esta com delay para ser perceptivo em ambiente fora do servidor.
  			$("#loader").delay(2000).fadeOut("slow");
  		});
  	</script> -->
    <script>
    let hoje = new Date();
    $(document).ready( function () {
        let today = hoje.getFullYear()+'-'+(hoje.getMonth() + 1)+'-'+hoje.getDate();
        $.get('http://<?php echo APP_HOST; ?>/tarefa/tarefasDia/' + today, function(data) {
            $('#tarefasDia').html(data);
            setTimeout(function() {
                $('.popoverr').popover();
            }, 500);
        });
    });

    $(document).on('click', '.prev, .next', function(el) {
        if ($(this).hasClass('prev')) {
            changeDate('minus', hoje);
        } else {
            changeDate('plus', hoje);
        }

        let data = hoje.getFullYear()+'-'+(hoje.getMonth() + 1)+'-'+hoje.getDate();

        $.get('http://<?php echo APP_HOST; ?>/tarefa/tarefasDia/' + data, function(data) {
            $('#tarefasDia').html(data);
            let day = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', year: 'numeric', month: 'numeric', day: 'numeric' }).format(hoje).replace(/^[\u00C0-\u1FFF\u2C00-\uD7FF\w]|\s[\u00C0-\u1FFF\u2C00-\uD7FF\w]/g, function(letter) {
                return letter.toUpperCase();
            });
            $('.taskDate').find('h5').text(day);
            setTimeout(function() {
                $('.popoverr').popover();
            }, 500);
        });
    });

    function changeDate(param, date) {
        if (param === 'minus') {
            date.setDate(date.getDate() - 1);
        } else {
            date.setDate(date.getDate() + 1);
        }
    }
    </script>
<?php
          date_default_timezone_set('America/Sao_Paulo');
          if (isset($viewVar['listaEventos'])){
          foreach ($viewVar['listaEventos'] as $tarefa){

                  }
                }
?>


    <script>
        $(document).ready(function() {
            $('#calendario').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                defaultDate: Date(),
                navLinks: true, // can click day/week names to navigate views
                editable: false,
                eventLimit: true, // allow "more" link when too many events
                events: [
                    <?php
                        if (isset($viewVar['listaEventos'])) {
                            foreach($viewVar['listaEventos'] as $eventos) {
                              if($eventos->getStatus() == 1){
                                  if ($eventos->getIdPrioridade() == 1) {
                                      $cor = $Sessao::retornaLogin()->getAlta() ? $Sessao::retornaLogin()->getAlta() : '#dc3545';
                                  } elseif ($eventos->getIdPrioridade() == 2) {
                                      $cor = $Sessao::retornaLogin()->getMedia() ? $Sessao::retornaLogin()->getMedia() : '#ffc107';
                                  } else {
                                      $cor = $Sessao::retornaLogin()->getBaixa() ? $Sessao::retornaLogin()->getBaixa() : '#28a745';
                                  }
                                }else{
                                    $cor = '#808080';
                                }
                                ?>
                                {
                                id: '<?php    echo $eventos->getIdTarefa(); ?>',
                                title: '<?php echo $eventos->getTitulo(); ?>',
                                start: '<?php echo $eventos->getDataTarefa()->format('Y-m-d H:i:s'); ?>',
                                end: '<?php echo $eventos->getDataTarefa()->format('Y-m-d H:i:s'); ?>',
                                color: '<?php echo $cor ?>'
                                },<?php
                            }
                        }
                        if (isset($viewVar['listaAniversarioContato'])) {
                              foreach($viewVar['listaAniversarioContato'] as $contato) {
                                ?>
                                {
                                id: '<?php    echo $contato->getIdContato(); ?>',
                                title: '<?php echo 'Aniversário de '.$contato->getNome(); ?>',
                                start: '<?php echo date("Y").'-'.$contato->getDataNascimento()->format('m-d'); ?>',
                                color: '#ffffffff',
                                borderColor: '#343a40',
                                },<?php
                              }
                        }
                    ?>
                ],
            });
        });

        function confirmacao(id) {
          swal({
              title: "Deseja excluir a tarefa?",
              text: "Após a exclusão, você pode restaurar quando quiser na lixeira!",
              icon: "warning",
              buttons: false,
              dangerMode: true,
              buttons: ["Cancelar", "Excluir"],
            })
            .then((willDelete) => {
              if (willDelete) {
                 window.location = 'http://<?php echo APP_HOST; ?>/tarefa/excluir/'+id;
              } else {

              }
            });
        }

    </script>

</body>
</html>
