<ul id="gn-menu" class="gn-menu-main">
    <li class="gn-trigger">
        <!-- <a class="gn-icon gn-icon-menu text-center px-0 py-2"><i class="fas fa-user-circle fa-3x"></i></a> -->
        <?php
        $sexo = $Sessao::retornaLogin()->getSexo();
        $fotouser = $Sessao::retornaLogin()->getFoto();
        if($fotouser == null){
             if($sexo == "m"){
            $foto = "http://sudesteclima.com.br/wp-content/uploads/2017/09/user-512.png";
            }else if($sexo == "f"){
                 $foto = "https://www1.icbas.up.pt/umib/images/research/girl-512.png";
            }else{
                 $foto = "http://globalstudy.com.br/wp-content/uploads/2016/12/blank-avatar.png";
            }
        }else{
            $foto = "http://lucasbaur.com.br/dia-a-dia/public/img/usuario/".$fotouser;
        }
       
        ?>

        <a class="gn-icon gn-icon-menu text-center px-0 py-0">
         <img src="<?php echo $foto ?>" name="aboutme" width="140" height="140" class="img-circle" style="display: inline-block;width: 40px;height: 40px;border-radius: 50%;">
     </a>
        <nav class="gn-menu-wrapper">
            <div class="gn-scroller">
                <ul class="gn-menu">
                    <li>
                        <a class="gn-icon fas fa-user"  href="http://<?php echo APP_HOST; ?>/perfil">Meu perfil</a>
                    </li>
                    <li>
                        <a class="gn-icon fas fa-users">Contatos</a>
                        <ul class="gn-submenu">
                            <li><a class="gn-icon fas fa-user-plus" href="http://<?php echo APP_HOST; ?>/contato/incluir">Novo contato</a></li>
                            <li><a class="gn-icon fas fa-user-friends" href="http://<?php echo APP_HOST; ?>/contato">Todos os contatos</a></li>
                        </ul>
                    </li>
                    <li>
                        <a class="gn-icon fas fa-tasks"  href="http://<?php echo APP_HOST; ?>/home/inicio">Tarefas</a>
                        <ul class="gn-submenu">
                            <li><a class="gn-icon fas fa-plus" href="http://<?php echo APP_HOST; ?>/tarefa/incluir">Nova tarefa</a></li>
                            <li><a class="gn-icon fas fa-trash-alt"  href="http://<?php echo APP_HOST; ?>/tarefa/lixeira">Lixeira</a></li>
                        </ul>
                    </li>
                    <li>
                        <a class="gn-icon fa fa-calendar"  href="http://<?php echo APP_HOST; ?>/calendario">Calendário</a>
                    </li>
                    <li><a class="gn-icon fas fa-door-open" href="http://<?php echo APP_HOST; ?>/login/logoff">Sair</a></li>
                </ul>
            </div><!-- /gn-scroller -->
        </nav>
    </li>
    <li>
        <span class="h5 mt-2"><?php echo $Sessao::retornaLogin()->getNome(); ?></span>
    </li>
    <li>
    <a href="http://<?php echo APP_HOST; ?>/home/inicio"><font size="5"><p>Dia-<i class="fa fa-heart" style="color: red"></i>-Dia</p></font></a>
    </li>

</ul>
