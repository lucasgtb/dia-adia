<div class="container mt-5 pt-5">
            <?php if($Sessao::retornaMensagem()){ ?>
              <script type="text/javascript">
                 swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
             </script>
        <?php } $Sessao::limpaMensagem(); ?>
        <h3 align="center">Calendário</h3>
    <div class="row">
        <?php
            if(!count($viewVar['listaEventos'])){
        ?>
            <div class="container">
                <div class="alert alert-info" role="alert" style="position:absolute;z-index:100;top:10%;align:center"> <!-- float: right;margin: 0 0 0em 60em; -->
                    <b>Atenção: </b>Nenhuma tarefa cadastrada!
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                </div>
            </div>
        <?php
        }
        ?>
        <div class="row mb-3">
             <div id='calendario'></div>
        </div>
         <div class='my-legend'>
          <div class='legend-title'>Legenda</div>
          <div class='legend-scale'>
            <ul class='legend-labels'>
              <li><span style='background:<?php echo $Sessao::retornaLogin()->getAlta() ?? '#dc3545'; ?>;'></span>Prioridade Alta</li>
              <li><span style='background:<?php echo $Sessao::retornaLogin()->getMedia() ?? '#ffc107'; ?>;'></span>Prioridade Média</li>
              <li><span style='background:<?php echo $Sessao::retornaLogin()->getBaixa() ?? '#28a745'; ?>;'></span>Prioridade Baixa</li>
              <li><span style='background:#FFFFFF;'></span>Aniversário</li>
              <li><span style='background:#808080;'></span>Tarefa Concluída</li>
            </ul>
          </div>
          <!-- <div class='legend-source'>Source: <a href="#link to source">Name of source</a></div> -->
          </div>

          <style type='text/css'>
            .my-legend .legend-title {
              text-align: left;
              margin-bottom: 5px;
              font-weight: bold;
              font-size: 90%;
              }
            .my-legend .legend-scale ul {
              margin: 0;
              margin-bottom: 5px;
              padding: 0;
              float: left;
              list-style: none;
              }
            .my-legend .legend-scale ul li {
              font-size: 80%;
              list-style: none;
              margin-left: 0;
              line-height: 18px;
              margin-bottom: 2px;
              }
            .my-legend ul.legend-labels li span {
              display: block;
              float: left;
              height: 16px;
              width: 30px;
              margin-right: 5px;
              margin-left: 0;
              border: 1px solid #999;
              }
            .my-legend .legend-source {
              font-size: 70%;
              color: #999;
              clear: both;
              }
            .my-legend a {
              color: #777;
              }
          </style>
    </div>
