<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo TITLE; ?> 404</title>
    <link href="http://<?php echo APP_HOST; ?>/public/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://<?php echo APP_HOST; ?>/public/css/404.css" rel="stylesheet">
</head>

<body class="bg-purple">

  <section class="page_404">
  	<div class="container">
  		<div class="row">
  		<div class="col-sm-12 ">
  		<div class="col-sm-10 col-sm-offset-1  text-center">
  		<div class="four_zero_four_bg">
  			<h1 class="text-center ">404</h1>


  		</div>

  		<div class="contant_box_404">
  		<h3 class="h2">
  		Parece que você está perdido
  		</h3>

  		<p>a página que você está procurando não está disponível!</p>

  		<a  href="http://<?php echo APP_HOST; ?>" class="link_404">Voltar para o sistema</a>
  	</div>
  		</div>
  		</div>
  		</div>
  	</div>
  </section>

    </body>
</html>
