<div class="container mt-5 pt-5">
    <h3 align="center">Lixeira</h3>
            <div class="card-body">
              <a href="http://<?php echo APP_HOST; ?>/tarefa/deletar" class="btn btn-danger"><i class="fas fa-trash"></i> Excluir todas</a>
            </div>
            <?php if($Sessao::retornaMensagem()){ ?>
                   <script type="text/javascript">
                      swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
                  </script>
              <?php $Sessao::limpaMensagem(); } ?>

            <div class="card-body">
                <?php if (isset($viewVar['listaLixeira'])): ?>

                    <?php foreach ($viewVar['listaLixeira'] as $tarefa): ?>
                      <?php if ($tarefa->getIdPrioridade() == 1) {
                          $cor = $Sessao::retornaLogin()->getAlta() ? $Sessao::retornaLogin()->getAlta() : '#dc3545';
                      } elseif ($tarefa->getIdPrioridade() == 2) {
                          $cor = $Sessao::retornaLogin()->getMedia() ? $Sessao::retornaLogin()->getMedia() : '#ffc107';
                      } else {
                          $cor = $Sessao::retornaLogin()->getBaixa() ? $Sessao::retornaLogin()->getBaixa() : '#28a745';
                      } ?>

                        <div class="card mb-3" style="border: 1px solid <?php echo $cor; ?>">
                            <div class="card-header bg-white border-0" style="cursor: pointer;" data-toggle="collapse" data-target="#card-body-<?php echo $tarefa->getIdTarefa(); ?>" aria-expanded="false" aria-controls="card-body-<?php echo $tarefa->getIdTarefa(); ?> ">
                                <div class="row">
                                    <div class="col-md-9 align-middle">
                                        <h6 class="card-title mb-0"><?php echo $tarefa->getTitulo(); ?></h6>
                                    </div>
                                    <div class="col-md-3 text-right">
                                        <div class="float-right">
                                            <div class="dropdown d-inline-block">
                                                <button type="button" class="btn btn-link text-dark" id="dropButton"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></button>
                                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropButton">
                                                    <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/deletar/'.$tarefa->getIdTarefa(); ?>"><i class="fas fa-trash"></i> Excluir</a>
                                                    <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/restaurar/'.$tarefa->getIdTarefa(); ?>"><i class="fas fa-recycle"></i> Restaurar</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body collapse" id="card-body-<?php echo $tarefa->getIdTarefa(); ?>">
                                <p><?php echo $tarefa->getDescricao(); ?></p>
                                <?php foreach ($viewVar['prioridades'] as $prioridade):
                                    $p = $prioridade->getIdPrioridade() == $tarefa->getIdPrioridade() ? $prioridade->getNome() : $p;
                                endforeach; ?>
                                <span class="badge badge-info"><i class="fas fa-compass"></i><?php echo $tarefa->getLocal(); ?></span>
                                <span class="badge " style="background-color: <?php echo $cor; ?>"><i class="fas fa-thermometer-quarter"></i> PRIORIDADE <?php echo $p; ?></span>
                                <?php if ($tarefa->getAlerta() == 1): ?>
                                    <span class="badge badge-warning float-right"><i class="fas fa-bell"></i></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
