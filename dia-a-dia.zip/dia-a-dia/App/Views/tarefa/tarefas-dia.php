
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <?php if (isset($viewVar['tarefas']) and !empty($viewVar['tarefas'])): ?>
                <?php $hora = '00'; ?>
                <?php $cor = ' '; ?>
                <?php foreach ($viewVar['tarefas'] as $tarefa): ?>
                    <?php if ($tarefa->getIdPrioridade() == 1) {
                        $cor = $Sessao::retornaLogin()->getAlta() ? $Sessao::retornaLogin()->getAlta() : '#dc3545';
                    } elseif ($tarefa->getIdPrioridade() == 2) {
                        $cor = $Sessao::retornaLogin()->getMedia() ? $Sessao::retornaLogin()->getMedia() : '#ffc107';
                    } else {
                        $cor = $Sessao::retornaLogin()->getBaixa() ? $Sessao::retornaLogin()->getBaixa() : '#28a745';
                    } ?>
                    <?php if ($tarefa->getDataTarefa()->format('H') > $hora): ?>
                        <?php $hora = $tarefa->getDataTarefa()->format('H'); ?>
                        <span class="text-muted"><?php echo $hora.':00'; ?><hr></span>
                    <?php endif; ?>
                    <div class="card mb-3 <?php echo $tarefa->getStatus() == 2 ? 'card-disabled' : '' ?>" style="border: 1px solid <?php echo $cor ?>" >
                        <div class="card-header bg-white border-0" style="cursor: pointer;" data-toggle="collapse" data-target="#card-body-<?php echo $tarefa->getIdTarefa(); ?>" aria-expanded="false" aria-controls="cad-body-<?php echo $tarefa->getIdTarefa(); ?>">
                            <div class="row">
                                <div class="col-md-9 align-middle">
                                    <h6 class="card-title mb-0"><?php echo $tarefa->getTitulo(); ?></h6>
                                </div>
                                <div class="col-md-3 text-right">
                                    <div class="float-right">
                                        <?php if ($tarefa->getStatus() == 1): ?>
                                            <div class="dropdown d-inline-block">
                                                <button type="button" class="btn btn-link text-dark" id="dropButton"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></button>
                                                <div class="dropdown-menu" aria-labelledby="dropButton">
                                                    <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/edicao/'.$tarefa->getIdTarefa(); ?>"><i class="fas fa-edit"></i> Editar</a>
                                                    <!-- <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/excluir/'.$tarefa->getIdTarefa(); ?>"><i class="fas fa-trash"></i> Excluir</a> -->
                                                    <a class="dropdown-item" href="javascript:func()"onclick="confirmacao('<?php echo $tarefa->getIdTarefa(); ?>')"><i class="fas fa-trash"></i> Excluir</a>
                                                    <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/concluir/'.$tarefa->getIdTarefa(); ?>"><i class="fas fa-check-square"></i> Concluir</a>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <!-- <i class="fas fa-check-double text-success"></i> -->
                                            <div class="dropdown d-inline-block">
                                                <button type="button" class="btn btn-link text-dark" id="dropButton"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></button>
                                                <div class="dropdown-menu" aria-labelledby="dropButton">
                                                    <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/excluir/'.$tarefa->getIdTarefa(); ?>"><i class="fas fa-trash"></i> Excluir</a>
                                                    <a class="dropdown-item" href="http://<?php echo APP_HOST.'/tarefa/desfazer/'.$tarefa->getIdTarefa(); ?>"><i class="fa fa-reply"></i> Desfazer</a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php $data = $tarefa->getDataTarefa(); ?>
                                    <?php if ($data->format('Y-m-d') < date('Y-m-d') or ($data->format('Y-m-d') == date('Y-m-d') and ($data->format('H') <= date('H') - 1 and $data->format('i') <= date('i') or $data->format('H') <= date('H') - 1))): ?>
                                        <span class="popoverr pulse float-right mt-2" data-toggle="popover" data-trigger="hover" title="Aviso" data-content="Tarefa atrasada!"><i class="fa fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-body collapse" id="card-body-<?php echo $tarefa->getIdTarefa(); ?>">
                            <p><?php echo $tarefa->getDescricao(); ?></p>
                            <span class="badge badge-info"><i class="fas fa-compass"></i> <?php echo $tarefa->getLocal(); ?></span>
                            <span class="badge badge-info"><i class="fas fa-hourglass-half"></i> <?php echo $tarefa->getDataTarefa()->format('H:i'); ?></span>
                            <?php foreach ($viewVar['prioridades'] as $prioridade):
                                $p = $prioridade->getIdPrioridade() == $tarefa->getIdPrioridade() ? $prioridade->getNome() : $p;
                            endforeach; ?>
                            <span class="badge " style="background-color: <?php echo $cor; ?>"><i class="fas fa-thermometer-quarter"></i> PRIORIDADE <?php echo $p; ?></span>
                            <?php if ($tarefa->getAlerta() == 1): ?>
                                <span class="badge badge-warning float-right popoverr" data-toggle="popover" data-trigger="hover" title="Alerta" data-content="<?php echo $tarefa->getTextoAlerta(); ?>"><i class="fas fa-bell"></i></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
              <div class="col-md-12 text-center">
                  <h3>Não há tarefas hoje.</h3>
              </div>
            <?php endif; ?>
        </div>
    </div>
</div>
