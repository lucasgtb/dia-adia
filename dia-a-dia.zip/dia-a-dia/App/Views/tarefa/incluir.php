<?php if($Sessao::retornaMensagem()){ ?>
  <script type="text/javascript">
     swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
 </script>
<?php } $Sessao::limpaMensagem(); ?>
<div class="container mt-5 pt-5">
                    <h3 align="center">Cadastro de Tarefa</h3>
                    <br>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-4">
            <form action="http://<?php echo APP_HOST; ?>/tarefa/cadastrar" method="post" id="form_cadastro">
                <div class="form-group">
                    <label for="titulo">Título*</label>
                    <input type="text" class="form-control"  name="titulo" placeholder="Título da tarefa" value="<?php echo $Sessao::retornaValorFormulario('titulo'); ?>" required>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <textarea rows="5" cols="33"  type="text" class="form-control" name="descricao" placeholder="Descrição da tarefa" value="<?php echo $Sessao::retornaValorFormulario('descricao'); ?>" ></textarea>
                </div>
                <div class="form-group">
                    <label for="local">Local</label>
                    <textarea type="text" class="form-control" name="local" rows="2" cols="33"  placeholder="" value="<?php echo $Sessao::retornaValorFormulario('local'); ?>" ></textarea>
                </div>

        </div>

        <div class="col-md-2"></div>
        <div class="col-md-4">
                <div class="form-group">
                    <label for="data">Data*</label>
                    <input type="date" class="form-control" name="data" placeholder="" min="<?php echo date('Y-m-d'); ?>"  value="<?php echo $Sessao::retornaValorFormulario('data') ? $Sessao::retornaValorFormulario('telefone') : date('Y-m-d'); ?>" required>
                </div>
                <div class="form-group">
                    <label for="hora">Horário*</label>
                    <input type="time" class="form-control" id="hora" name="hora" value="<?php echo $Sessao::retornaValorFormulario('hora'); ?>" required>
                </div>
                <div class="form-group">
                    <label for="alerta">Alerta</label> <br>
                    <div class="row">
                      <div class="col-sm">
                        <label><input type="radio" class="input-checkbox100" name="alerta" value="1" id="alerta_sim" onClick="habilitacao()" > Sim</label>
                      </div>
                      <div class="col-sm">
                        <label><input class="input-radio100" type="radio" name="alerta" value="0" id="alerta_nao" onClick="habilitacao()" checked> Não</label>
                    </div>
                  </div>
                      <textarea disabled type="text" class="form-control" id="config_alerta" name="textoAlerta" rows="1" cols="33"  placeholder=""  required></textarea>
                </div>
                <div class="form-group">
                    <label for="idPrioridade">Prioridade*</label>
                    <?php //var_dump($viewVar['prioridades']); ?>
                    <select class="form-control" name="idPrioridade" id="idPrioridade" required>
                      <option selected></option>
                      <?php if (isset($viewVar['prioridades'])): ?>
                          <?php foreach ($viewVar['prioridades'] as $prioridade): ?>
                              <option value="<?php echo $prioridade->getIdPrioridade(); ?>"><?php echo $prioridade->getNome(); ?></option>
                          <?php endforeach; ?>
                      <?php endif; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-success btn-sm">Confirmar</button>
                <a href="http://<?php echo APP_HOST; ?>/home" class="btn btn-danger btn-sm">Cancelar</a>
                </form>
        </div>
    </div>

</div>
<script language="javascript">
    function habilitacao(){
      if(document.getElementById('alerta_sim').checked == true){
        document.getElementById('config_alerta').disabled = false;
      }
      if(document.getElementById('alerta_sim').checked == false){
        document.getElementById('config_alerta').disabled = true;
      }
    }
  </script>
