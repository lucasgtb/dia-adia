<?php if($Sessao::retornaMensagem()){ ?>
  <script type="text/javascript">
     swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
 </script>
<?php } $Sessao::limpaMensagem(); ?>
<div class="container mt-5 pt-5">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">

            <h3>Excluir Tarefa</h3>
            <?php if(is_array($viewVar['tarefa'])){ ?>
              <form action="http://<?php echo APP_HOST.'/tarefa/exclusao/' ?>" method="post" id="form_cadastro">
                  <div class="panel panel-danger">
                      <div class="panel-body">
                          <span class="text-muted d-block my-0 ml-0">Deseja realmente excluir todas as taferas</span> <br>
                      </div>
                      <div class="panel-footer">
                          <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                          <a href="http://<?php echo APP_HOST; ?>/tarefa/lixeira" class="btn btn-info btn-sm">Voltar</a>
                      </div>
                  </div>
              </form>
            <?php }else{ ?>
              <form action="http://<?php echo APP_HOST.'/tarefa/exclusao/'.$viewVar['tarefa']->getIdTarefa(); ?>" method="post" id="form_cadastro">
                  <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $viewVar['tarefa']->getIdTarefa(); ?>">

                  <div class="panel panel-danger">
                      <div class="panel-body">
                          <span class="text-muted d-block my-0 ml-0">Deseja realmente excluir a Terefa: <?php echo $viewVar['tarefa']->getTitulo(); ?> ? </span> <br>
                      </div>
                      <div class="panel-footer">
                          <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                          <a href="http://<?php echo APP_HOST; ?>/tarefa/lixeira" class="btn btn-info btn-sm">Voltar</a>
                      </div>
                  </div>
              </form>
            <?php } ?>
        </div>
        <div class=" col-md-3"></div>
    </div>
</div>
