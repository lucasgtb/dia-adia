<div class="container mt-5 pt-5">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <h3>Novo Contato</h3>

            <?php if($Sessao::retornaMensagem()){ ?>
              <script type="text/javascript">
                 swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
             </script>
        <?php } $Sessao::limpaMensagem(); ?>

            <form action="http://<?php echo APP_HOST; ?>/contato/salvar" method="post" id="form_cadastro">
                <div class="form-group">
                    <label for="nome">Nome*</label>
                    <input type="text" class="form-control"  name="nome" placeholder="" value="<?php echo $Sessao::retornaValorFormulario('nome'); ?>" required>

                </div>
                <div class="form-group">
                    <label for="email">Email*</label>
                    <input type="email" class="form-control" name="email" placeholder="" value="<?php echo $Sessao::retornaValorFormulario('email'); ?>" required>

                </div>
                <div class="form-group">
                    <label for="data_nascimento">Data Nascimento*</label>
                    <input type="date" class="form-control" name="data_nascimento" placeholder="" value="<?php echo $Sessao::retornaValorFormulario('data_nascimento'); ?>" required>

                </div>
                <div class="form-group">
                    <label for="telefone">Telefone*</label>
                    <input pattern=".{14,15}" type="tel" class="form-control" name="telefone"  id="telefone"  minlenght="14"  placeholder="" value="<?php echo $Sessao::retornaValorFormulario('telefone'); ?>" required>

                </div>

                <button type="submit" class="btn btn-success btn-sm">Salvar</button>
            </form>
        </div>
        <div class=" col-md-3"></div>
    </div>
</div>

<script type="text/javascript">
/* Máscaras ER */
function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
function id( el ){
  return document.getElementById( el );
}
window.onload = function(){
  id('telefone').onkeypress = function(){
    mascara( this, mtel );
  }
}

</script>
