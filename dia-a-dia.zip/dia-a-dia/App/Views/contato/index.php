
<div class="container mt-5 pt-5">
  <?php if($Sessao::retornaMensagem()){ ?>
    <script type="text/javascript">
       swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
   </script>
<?php } $Sessao::limpaMensagem(); ?>
        <h3 align="center">Contatos</h3>
    <div class="row">

        <?php
            if(!count($viewVar['listaContatos'])){
        ?>
            <div class="alert alert-info" role="alert" style="position:absolute;z-index:100;top:10%;align:center"> <!-- float: right;margin: 0 0 0em 60em; -->
                Nenhum contato encontrado
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
        <?php
            } else {
        ?>
            <?php
            foreach($viewVar['listaContatos'] as $contato) {
            ?>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body px-2">
                        <div class="float-right">
                            <div class="dropdown d-inline-block">
                                <button type="button" class="btn btn-link text-dark" id="dropButton"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropButton">
                                    <a class="dropdown-item" href="contato/alterar/<?php echo $contato->getIdContato(); ?>"><i class="fas fa-edit"></i> Editar</a>
                                    <a class="dropdown-item" href="contato/excluir/<?php echo $contato->getIdContato(); ?>"><i class="fas fa-trash"></i> Excluir</a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <style type="text/css">
                                    .fa-user {
                                      color: #415A77;
                                    }
                                </style>
                                <i class="far fa-user fa-3x"></i>
                            </div>
                            <div class="col-md-9">
                                <h4 class="card-title mt-2"><?php echo $contato->getNome(); ?></h4>
                                <span class="text-muted d-block my-0 ml-0"><?php echo $contato->getEmail(); ?></span>
                                <span class="text-muted d-block my-0 ml-0"><?php echo $contato->getTelefone(); ?></span>
                                <span class="text-muted d-block my-0 ml-0">
                                    <?php echo $contato->getDataNascimento()->format('d/m/Y'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            }
        }
            ?>
    </div>
</div>

<script type="text/javascript">
window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove();
    });
}, 4000);
</script>
