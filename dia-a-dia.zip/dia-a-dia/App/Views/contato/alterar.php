<div class="container mt-5 pt-5">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <h3>Editar Contato</h3>

            <?php if($Sessao::retornaMensagem()){ ?>
              <script type="text/javascript">
                 swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
             </script>
        <?php } $Sessao::limpaMensagem(); ?>
                </div>
            <?php } ?>

            <form action="http://<?php echo APP_HOST; ?>/contato/atualizar" method="post" id="form_cadastro">
                <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $viewVar['contato']->getIdContato(); ?>">

                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" class="form-control"  name="nome" placeholder="" value="<?php echo $viewVar['contato']->getNome(); ?>" required>

                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" placeholder="" value="<?php echo $viewVar['contato']->getEmail(); ?>" required>

                </div>
                <div class="form-group">
                    <label for="data_nascimento">Data Nascimento</label>
                    <input type="date" class="form-control" name="data_nascimento" placeholder="" value="<?php echo $viewVar['contato']->getDataNascimento()->format('Y-m-d'); ?>" required>

                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="text" class="form-control" id="telefone" onBlur="v();" minlength="10"  maxlength="15" value="<?php echo $viewVar['contato']->getTelefone(); ?>" name="telefone" placeholder="" required>

                </div>

                <button type="submit" class="btn btn-success btn-sm">Alterar</button>
                <a href="http://<?php echo APP_HOST; ?>/contato" class="btn btn-danger btn-sm">Cancelar</a>
            </form>
        </div>
        <div class=" col-md-3"></div>
    </div>
</div>

<script type="text/javascript">
function v(){	tam = document.getElementById('telefone').value	if(tam.length  < 8) document.getElementById('telefone').focus();}


/* Máscaras ER */
function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
function id( el ){
  return document.getElementById( el );
}
window.onload = function(){
  id('telefone').onkeypress = function(){
    mascara( this, mtel );
  }
}

</script>
