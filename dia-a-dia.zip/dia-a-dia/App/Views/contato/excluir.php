<div class="container mt-5 pt-5">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">

            <h3>Excluir Contato</h3>

            <?php if($Sessao::retornaMensagem()){ ?>
              <script type="text/javascript">
                 swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
             </script>
        <?php } $Sessao::limpaMensagem(); ?>

            <form action="http://<?php echo APP_HOST; ?>/contato/exclusao" method="post" id="form_cadastro">
                <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $viewVar['contato']->getIdContato(); ?>">

                <div class="panel panel-danger">
                    <div class="panel-body">
                        <span class="text-muted d-block my-0 ml-0">Deseja realmente excluir o contato: <?php echo $viewVar['contato']->getNome(); ?> ? </span> <br>
                    </div>
                    <div class="panel-footer">
                        <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                        <a href="http://<?php echo APP_HOST; ?>/contato" class="btn btn-info btn-sm">Voltar</a>
                    </div>
                </div>
            </form>
        </div>
        <div class=" col-md-3"></div>
    </div>
</div>
