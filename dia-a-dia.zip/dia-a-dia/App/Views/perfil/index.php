<script type="text/javascript">
function Valida(){
    var senha = $("#nova_senha").val();
    var senha2 = $("#confirmacao_nova_senha").val();

    var s = true;
    var s2 = true;

    if(senha === ''){

    }else{
        if(senha.length >= 6){

        $("#nova_senha").css("color", "#4769eb");
          document.getElementById("label1").innerHTML ="";

          if(senha.localeCompare(senha2))
          {
              s2 = false;
              s = false;
              $("#confirmacao_nova_senha").css("border", "2px  #ff0000");
              $("#confirmacao_nova_senha").css("color", "#ff0000");
              document.getElementById("label2").innerHTML ="Senhas diferentes!";
              document.getElementById("confirmacao_nova_senha").focus();
          }
          else{
            $("#confirmacao_nova_senha").css("color", "#4769eb");
              $("#confirmacao_nova_senha").css("color", "#000000");
              document.getElementById("label2").innerHTML ="";
              s2 = true;
              s = true;
          }
        }else{
            s2 = false;
            s = false;
            $("#nova_senha").css("border", "2px  #ff0000");
            $("#nova_senha").css("color", "#ff0000");
            document.getElementById("label1").innerHTML ="Mínimo 6 caractes!";
            document.getElementById("nova_senha").focus();
        }
    }

    if( s2==false  ||  s ==false  )
    {
        return false;
    }

    return true;
}

</script>

<div class="container mt-5 pt-5">
<div class="container">
	            <h3 align="center">Meu Perfil</h3><br>
    <div class="row my-1">
      <?php if($Sessao::retornaMensagem()){ ?>
        <script type="text/javascript">
           swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
       </script>
  <?php } $Sessao::limpaMensagem(); ?>

    	        <div class="col-lg-4 order-lg-1 text-center">
    	     <?php
    	    if($viewVar['usuario']->getFoto() == null){
	            if($sexo == "m"){
	            $f = "http://sudesteclima.com.br/wp-content/uploads/2017/09/user-512.png";
	            }else if($sexo == "f"){
	                 $f = "https://www1.icbas.up.pt/umib/images/research/girl-512.png";
	            }else{
	                 $f = "http://globalstudy.com.br/wp-content/uploads/2016/12/blank-avatar.png";
	            }
	        }else{
	            $f = "http://lucasbaur.com.br/dia-a-dia/public/img/usuario/".$viewVar['usuario']->getFoto() ;
	        }


    	     ?>
            <img src="<?php echo $f ?>" class="mx-auto img-fluid img-circle d-block" style="display: inline-block;width: 150px;height: 150px;border-radius: 50%;background-repeat: no-repeat;background-position: center center;background-size: cover;" alt="avatar">
            <!-- <h6 class="mt-2">Mudar minha foto</h6> -->
        </div>
        <div class="col-lg-8 order-lg-2">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a href="" data-target="#profile" data-toggle="tab" class="nav-link active">Perfil</a>
                </li>
                <li class="nav-item">
                    <a href="" data-target="#edit" data-toggle="tab" class="nav-link">Alterar</a>
                </li>
            </ul>
            <div class="tab-content py-4">
                <div class="tab-pane active" id="profile">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Nome</h6>
                            <p>
                               	<?php echo $viewVar['usuario']->getNome(); ?>
                            </p>
                        	<h6>Sexo</h6>
                            <p>
                                <?php
                                $sexo = $viewVar['usuario']->getSexo();
                                if($sexo == 'n'){
                                	echo "Não informado";
                                }else if($sexo == 'm'){
                                	echo "Masculino";
                                }else{
                                	echo "Feminino";
                                } ?>
                            </p>
                            <h6>Telefone</h6>
                            <p>
                               	<?php echo $viewVar['usuario']->getTelefone(); ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                        	<h6>Email</h6>
                            <p>
                                <?php echo $viewVar['usuario']->getEmail(); ?>
                            </p>
                            <h6>Data de Nascimento</h6>
                            <p>
                                <?php
                                $DataNascimento = $viewVar['usuario']->getDataNascimento();
                                echo date_format($DataNascimento, 'd/m/Y');
                                ?>
                            </p>
                        </div>
                    </div>
                    <h5 class="mb-3" align="center">Preferências</h5><br>
                                                <h6>Cores Prioridades</h6>
                <div class="row">
                             <div class="col-md-2">
                            <p align="center">
                               	 <span class="badge badge"style="color: <?php echo $viewVar['usuario']->getAlta() ? $viewVar['usuario']->getAlta() : '#dc3545'; ?> ; height:30px; width:60px;"><i class="fas fa-thermometer-quarter fa-3x"></i> <h6 align="center">Alta</h6></span>
                            </p>
                            <!-- <input type="text" class="form-control form-control-sm" value="#dc3545" disabled> -->
                        	</div>
                        	<div class="col-md-2">
                            <p align="center">
                               	 <span class="badge badge"style="color: <?php echo $viewVar['usuario']->getMedia() ? $viewVar['usuario']->getMedia() : '#ffc107'; ?> ; height:30px; width:60px;"><i class="fas fa-thermometer-quarter fa-3x"></i> <h6 align="center">Média</h6></span>
                            </p>
                            <!--<input type="text" class="form-control form-control-sm" value="#ffc107" disabled> -->
                        	</div>
                        	<div class="col-md-2">
                            <p align="center">
                               	 <span class="badge badge"style="color: <?php echo $viewVar['usuario']->getBaixa() ? $viewVar['usuario']->getBaixa() : '#28a745'; ?> ; height:30px; width:60px;"><i class="fas fa-thermometer-quarter fa-3x"></i> <h6 align="center">Baixa</h6></span>
                            </p>
                            <!-- <input type="text" class="form-control form-control-sm" value="#28a745" disabled> -->
                        	</div>
                        </div>
                    <!--/row-->
                </div>
                <div class="tab-pane" id="edit">
                    <form  onsubmit="return Valida();" action="http://<?php echo APP_HOST; ?>/perfil/atualizar" method="post" id="form_cadastro" role="form"  enctype="multipart/form-data">
                    	<input type="hidden" class="form-control" name="id" id="id" value="<?php echo $Sessao::retornaLogin()->getIdUsuario(); ?>">
                    	<input type="hidden" class="form-control" name="senha" id="senha" value="<?php echo $Sessao::retornaLogin()->getSenha(); ?>">
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Foto Perfil</label>
                            <div class="col-lg-9">
								<div class="input-group mb-3">
								  <div class="input-group-prepend">
								    <span class="input-group-text">Upload</span>
								  </div>
								  <div class="custom-file">
								    <input type="file" class="custom-file-input" name="foto" id="inputArquivo">
								    <label class="custom-file-label" for="inputGroupFile01"><div class="botaoArquivo">Selecionar arquivo...</div></label>
								  </div>
								</div>
                            </div>
                        </div>
                        <!-- <input name="foto" id="foto" type="file" /> -->
   <br />

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Senha</label>
                            <div class="col-lg-9">
                                <label id="label1" style="color:red; font-size:12px; text-align: center; position: absolute; padding: 20px 20px 15px 25px;"></label>
                                <input class="form-control" type="password" name="nova_senha" id="nova_senha">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Confirme a senha*</label>
                            <div class="col-lg-9">
                                   <label id="label2" style="color:red; font-size:12px; text-align: center; position: absolute; padding: 20px 20px 15px 25px;"></label>
                                <input class="form-control" type="password" name="confirmacao_nova_senha" id="confirmacao_nova_senha">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Telefone</label>
                            <div class="col-lg-9">
                                <input pattern=".{14,15}" class="form-control" type="text" name="telefone" id="telefone" maxlength="15" value="<?php echo $viewVar['usuario']->getTelefone(); ?>" required>
                            </div>
                        </div>
                         <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Prioridade</label>
                            <div class="col-lg-9">
                            	<div class="row">
                            		<div class="col-md-2">
                                		<input type="color" class="form-control" name="alta" value="<?php echo $viewVar['usuario']->getAlta() ? $viewVar['usuario']->getAlta() : '#dc3545'; ?>"><p align="center">Alta</p>
                                	</div>
                                	<div class="col-md-2">
                               			<input type="color" class="form-control" name="media" value="<?php echo $viewVar['usuario']->getMedia() ? $viewVar['usuario']->getMedia() : '#ffc107'; ?>"><p align="center">Média</p>
                               		</div>
                               		<div class="col-md-2">
                                		<input type="color" class="form-control" name="baixa" value="<?php echo $viewVar['usuario']->getBaixa() ? $viewVar['usuario']->getBaixa() : '#28a745'; ?>"><p align="center">Baixa</p>
                                	</div>
                            	</div>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label"></label>
                            <div class="col-lg-9">
                                 <input type="submit" class="btn btn-primary" value="Alterar">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</div>

<script type="text/javascript">
	var div = document.getElementsByClassName("botaoArquivo")[0];
	var input = document.getElementById("inputArquivo");

	div.addEventListener("click", function(){
	    input.click();
	});
	input.addEventListener("change", function(){
	    var nome = "Não há arquivo selecionado. Selecionar arquivo...";
	    if(input.files.length > 0) nome = input.files[0].name;
	    div.innerHTML = nome;
	});


/* Máscaras ER */
function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que não é dígito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca parênteses em volta dos dois primeiros dígitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca hífen entre o quarto e o quinto dígitos
    return v;
}
function id( el ){
  return document.getElementById( el );
}
window.onload = function(){
  id('telefone').onkeypress = function(){
    mascara( this, mtel );
  }
}

</script>

<style type="text/css">
	#inputArquivo { display: none; }
</style>
