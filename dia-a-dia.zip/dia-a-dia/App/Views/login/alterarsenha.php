

<!DOCTYPE html>
<html lang="pt">
<head>
    <title>Dia-a-Dia</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="http://<?php echo APP_HOST; ?>/public/login/images/icons/favicon.ico"/>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/css/util.css">
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/css/main.css">

    <!--===============================================================================================-->



    <script type="text/javascript">
    function Valida(){
    var senha = $("#senha").val();
    var senha2 = $("#senha2").val();

    var s = true;
    var s2 = true;

    if(senha === ''){

    }else{
        if(senha.length >= 6){

          $("#senha").css("color", "#000000");
          document.getElementById("label1").innerHTML ="";

          if(senha.localeCompare(senha2))
          {
              s2 = false;
              s = false;
              $("#senha2").css("border", "2px  #ff0000");
              $("#senha2").css("color", "#ff0000");
              document.getElementById("label2").innerHTML ="Senhas diferentes!";
              document.getElementById("senha2").focus();
          }
          else{
              $("#senha2").css("color", "#000000");
              document.getElementById("label2").innerHTML ="";
              s2 = true;
              s = true;
          }
        }else{
            s2 = false;
            s = false;
            $("#senha").css("border", "2px  #ff0000");
            $("#senha").css("color", "#ff0000");
            document.getElementById("label1").innerHTML ="Mínimo 6 caractes!";
            document.getElementById("senha").focus();
        }
    }

    if( s2==false  ||  s ==false  )
    {
        return false;
    }

   // return true;
}
</script>


</head>
<body style="background-color: #666666;">

    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login1001">
              <?php if($Sessao::retornaMensagem()){ ?>
                <script type="text/javascript">
                   swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
               </script>
          <?php } $Sessao::limpaMensagem(); ?>
                <form onsubmit="return Valida();" class="login1001-form validate-form" name="f1" method="POST" action="http://<?php echo APP_HOST; ?>/login/atualizar">
                    <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $viewVar['usuario']->getIdUsuario(); ?>">
                    <span class="login1001-form-title p-b-43">
                        Alterar Senha
                    </span>

                    <label id="label1" style="color:red; font-size:12px; text-align: center; position: absolute; padding: 15px 15px 15px 25px;"></label>

                    <div class="wrap-input1001 validate-input" data-validate="Campo Obrigatório">
                        <input class="input100" type="password" id="senha" name="senha" onkeyup="javascript:verifica()">
                        <span class="focus-input100"></span>
                        <span class="label-input1001">Senha</span>
                    </div>

                    <label id="label2" style="color:red; font-size:12px; text-align: center; position: absolute; padding: 15px 15px 15px 25px;"></label>

                    <div class="wrap-input1001 validate-input" data-validate="Campo Obrigatório">
                        <input class="input100" type="password" id="senha2" name="senha2" >
                        <span class="focus-input100"></span>
                        <span class="label-input1001">Repita a senha</span>
                    </div>

                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn">
                            Alterar senha
                        </button>
                    </div>

                    <div class="text-center p-t-46 p-b-20">
                        <span class="txt2">
                            <a href="http://<?php echo APP_HOST; ?>/">Login</a>
                        </span>
                    </div>

                    <!-- <div class="login100-form-social flex-c-m">
                    <a href="#" class="login100-form-social-item flex-c-m bg1 m-r-5">
                    <i class="fa fa-facebook-f" aria-hidden="true"></i>
                </a>

                <a href="#" class="login100-form-social-item flex-c-m bg2 m-r-5">
                <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
        </div> -->
    </form>
    <!-- <div class="login100-more" style="background-image: url('http://<?php echo APP_HOST; ?>/public/login/images/image1.png');"> -->
    <div class="login100-more" style="background-image: url('https://images.unsplash.com/photo-1540921002383-b2a7ff6a716d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80');">
    </div>
</div>
</div>
</div>

<!--===============================================================================================-->


<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/bootstrap/js/popper.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/daterangepicker/moment.min.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/js/main.js"></script>

</body>
</html>
