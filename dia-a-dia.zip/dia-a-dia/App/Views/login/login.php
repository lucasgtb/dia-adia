<!DOCTYPE html>
<html lang="pt">
<head>
    <title>Dia-a-Dia</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="http://<?php echo APP_HOST; ?>/public/login/images/icons/favicon.ico"/>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/css/util.css">
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/css/main.css">
    <link rel="stylesheet" type="text/css" href="http://<?php echo APP_HOST; ?>/public/login/css/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" href="http://<?php echo APP_HOST; ?>/public/loader/css/style.css" media="screen"/>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body style="background-color: #666666;">
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
              <?php if($Sessao::retornaMensagem()){ ?>
                <script type="text/javascript">
                   swal("<?php echo $Sessao::retornaTituloMensagem(); ?>", "<?php echo $Sessao::retornaMensagem(); ?>", "<?php echo $Sessao::retornaTipoMensagem(); ?>");
               </script>
          <?php } $Sessao::limpaMensagem(); ?>
                <form action="http://<?php echo APP_HOST; ?>/login/login" class="login100-form validate-form" method="POST">
                    <!--  class="animated infinite heartBeat" -->
                    <div align="center"><h2>Dia-<i class="fa fa-heart" aria-hidden="true"></i>-Dia</h2></div>
                    <span class="login100-form-title p-b-43">
                        Entrar
                    </span>


                    <div class="wrap-input1001 validate-input" data-validate = "Informe um email válido: ex@abc.xyz">
                        <input class="input100" type="text" name="email" value="<?php echo $Sessao::retornaValorFormulario('email'); ?>">
                        <span class="focus-input1001"></span>
                        <span class="label-input1001">Email</span>
                    </div>


                    <div class="wrap-input1001 validate-input" data-validate="Campo Obrigatório">
                        <input class="input100" type="password" name="senha">
                        <span class="focus-input1001"></span>
                        <span class="label-input1001">Senha</span>
                    </div>

                    <div class="flex-sb-m w-full p-t-3 p-b-32">
                      <div class="contact100-form-checkbox">
                              <!-- <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
                            <label class="label-checkbox100" for="ckb1">
                                Lembrar-me
                            </label> -->
                        </div>

                        <div>
                            <a href="http://<?php echo APP_HOST; ?>/login/recuperarsenha" class="txt1">
                                Esqueci minha senha
                            </a>
                        </div>
                    </div>

                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn">
                            Login
                        </button>
                    </div>
                    <div class="text-center p-t-46 p-b-20">
                        <span class="txt2">
                            <a href="http://<?php echo APP_HOST; ?>/login/registro">Crie uma conta</a>
                        </span>
                    </div>

                    <!-- <div class="login100-form-social flex-c-m">
                    <a href="#" class="login100-form-social-item flex-c-m bg1 m-r-5">
                    <i class="fa fa-facebook-f" aria-hidden="true"></i>
                </a>

                <a href="#" class="login100-form-social-item flex-c-m bg2 m-r-5">
                <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
        </div> -->
    </form>
    <div class="login100-more" style="background-image: url('http://<?php echo APP_HOST; ?>/public/login/images/image1.png');">
    </div>
</div>
</div>
</div>

<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/bootstrap/js/popper.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/daterangepicker/moment.min.js"></script>
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="http://<?php echo APP_HOST; ?>/public/login/js/main.js"></script>

<script type="text/javascript">
// Este evendo é acionado após o carregamento da página
jQuery(window).load(function() {
    //Após a leitura da pagina o evento fadeOut do loader é acionado, esta com delay para ser perceptivo em ambiente fora do servidor.
    jQuery("#loader").delay(2000).fadeOut("slow");
});
</script>

<div id="loader">  </div>

<!--
<script type="text/javascript">
var jbkrAlert = (function () {
    var criarModal = function () {
        var modal = $('<div class="modal modal-alerta"><div class="modal-dialog"><div class="modal-content"><div class="modal-body"></div></div></div></div>');
        modal.modal('show').on('hidden', function () {
            $('.modal-alerta').remove();
        });
    }

    var exibirAlerta = function (titulo, mensagem) {
        criarModal();
        var conteudo = $('<div class="alert alert-warning">' +
        '<b><i class="icon-warning-sign"></i> ' + titulo + '</b></br>' +
        '' + mensagem + '' +
        '<button type="button" class="btn btn-warning" data-dismiss="modal">Fechar</button></div>');
        $('.modal-alerta .modal-body').html(conteudo);

    };

    var exibirErro = function (titulo, mensagem) {
        criarModal();
        var conteudo = $('<div class="alert alert-danger">' +
        '<b><i class="icon-exclamation-sign"></i> ' + titulo + '</b></br>' +
        '' + mensagem + '' +
        '<button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button></div>');
        $('.modal-alerta .modal-body').html(conteudo);
    };

    var exibirSucesso = function (titulo, mensagem) {
        criarModal();
        var conteudo = $('<div class="alert alert-success">' +
        '<b><i class="icon-info-sign"></i> ' + titulo + '</b></br>' +
        '' + mensagem + '' +
        '<button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button></div>');
        $('.modal-alerta .modal-body').html(conteudo);
    };

    return {
        alerta: exibirAlerta,
        erro: exibirErro,
        sucesso: exibirSucesso
    };
})();

$(".login100-form-btn").on('click', (evt) => {
    evt.preventDefault();
    $.post('http://<?php echo APP_HOST; ?>' + $(".login100-form-btn").parents('form').attr('action'), $(".login100-form-btn").parents('form').serialize(), (data) => {
        console.log(data);
        if (data == 200) {
            window.location.href = 'http://<?php echo APP_HOST."/home/inicio" ?>';
        } else {
            jbkrAlert.erro('Erro ao efetuar login', 'E-mail ou Senha inválidos!');
        }
    });
});



</script>
-->


</body>
</html>
