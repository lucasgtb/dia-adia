<?php

namespace App\Lib;

use App\Models\Entidades\Usuario;

class Sessao
{
    public static function gravaMensagem($titulo,$mensagem,$tipo){
        $_SESSION['titulo_mensagem'] = $titulo;
        $_SESSION['mensagem'] = $mensagem;
        $_SESSION['tipo_mensagem'] = $tipo;
    }

    public static function limpaMensagem(){
        unset($_SESSION['titulo_mensagem']);
        unset($_SESSION['mensagem']);
        unset($_SESSION['tipo_mensagem']);
    }

   public static function retornaTituloMensagem(){
        return ($_SESSION['titulo_mensagem']) ? $_SESSION['titulo_mensagem'] : "";
    }

    public static function retornaMensagem(){
        return ($_SESSION['mensagem']) ? $_SESSION['mensagem'] : "";
    }

    public static function retornaTipoMensagem(){
        return ($_SESSION['tipo_mensagem']) ? $_SESSION['tipo_mensagem'] : "";
    }

    public static function gravaFormulario($form){
        $_SESSION['form'] = $form;
    }

    public static function limpaFormulario(){
        unset($_SESSION['form']);
    }

    public static function retornaValorFormulario($key){
        return (isset($_SESSION['form'][$key])) ? $_SESSION['form'][$key] : "";
    }

    public static function existeFormulario(){
        return (isset($_SESSION['form'])) ? $_SESSION['form'] : "";
    }

    public static function gravaErro($erros){
        $_SESSION['erro'] = $erros;
    }

    public static function retornaErro(){
       return (isset($_SESSION['erro'])) ? $_SESSION['erro'] : false;
    }

    public static function limpaErro(){
        unset($_SESSION['erro']);
    }

    public static function gravaLogin(Usuario $login){
        $_SESSION['login'] = $login;
    }

    public static function limpaLogin(){
        unset($_SESSION['login']);
    }

    public static function retornaLogin(){
        return (isset($_SESSION['login'])) ? $_SESSION['login'] : false;
    }

}
