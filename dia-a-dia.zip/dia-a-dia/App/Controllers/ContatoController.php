<?php

namespace App\Controllers;

use App\Lib\Sessao;
use App\Models\DAO\ContatoDAO;
use App\Models\Entidades\Contato;
use App\Models\Validacao\ContatoValidador;

class ContatoController extends Controller {

    public function index() {

        if ($this->verifyLogin() !== false) {
            $contatoDAO = new ContatoDAO();

            self::setViewParam('listaContatos', $contatoDAO->select("SELECT * FROM Contato WHERE idUsuario = ".Sessao::retornaLogin()->getIdUsuario())->fetchAll(\PDO::FETCH_CLASS, Contato::class));

            $this->render('contato/index');


            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }

    }
    public function alterar($params)
    {
        if ($this->verifyLogin() !== false) {
            $id = $params[0];

            $contatoDAO = new ContatoDAO();

            $contato = $contatoDAO->select("SELECT * FROM Contato WHERE idUsuario = ".Sessao::retornaLogin()->getIdUsuario()." AND idContato = {$id}")->fetchObject(Contato::class);

            if(!$contato){
                Sessao::gravaMensagem("Ops","Contato de código ".$id." inexistente.","error");
                $this->redirect('/contato');
            }

            self::setViewParam('contato', $contato);

            $this->render('/contato/alterar');

            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }

    }

    public function incluir()
    {
        if ($this->verifyLogin() !== false) {
            $this->render('contato/incluir');

            Sessao::limpaFormulario();
            Sessao::limpaMensagem();
            Sessao::limpaErro();
        } else {
            $this->redirect('/login');
        }
    }

    public function salvar()
    {
        if ($this->verifyLogin() !== false) {
            $Contato = new Contato();
            $Contato->setNome($_POST['nome']);
            $Contato->setEmail($_POST['email']);
            $Contato->setDataNascimento($_POST['data_nascimento']);
            $Contato->setTelefone($_POST['telefone']);
            $Contato->setIdUsuario(Sessao::retornaLogin()->getIdUsuario());

            Sessao::gravaFormulario($_POST);

            $contatoValidador = new ContatoValidador();
            $resultadoValidacao = $contatoValidador->validar($Contato);

            if($resultadoValidacao->getErros()){
                Sessao::gravaErro($resultadoValidacao->getErros());
                $this->redirect('/contato/incluir');
            }

            $contatoDAO = new ContatoDAO();

            $contatoDAO->salvar($Contato);

            Sessao::limpaFormulario();
            Sessao::limpaMensagem();
            Sessao::limpaErro();
            Sessao::gravaMensagem("Parabéns","Contato incluído com sucesso!","success");
            $this->redirect('/contato');
        } else {
            $this->redirect('/login');
        }
    }

    public function atualizar()
    {

        if ($this->verifyLogin() !== false) {
            $Contato = new Contato();
            $Contato->setIdContato($_POST['id']);
            $Contato->setIdUsuario(Sessao::retornaLogin()->getIdUsuario());
            $Contato->setNome($_POST['nome']);
            $Contato->setEmail($_POST['email']);
            $Contato->setDataNascimento($_POST['data_nascimento']);
            $Contato->setTelefone($_POST['telefone']);

            Sessao::gravaFormulario($_POST);

            $contatoValidador = new ContatoValidador();
            $resultadoValidacao = $contatoValidador->validar($Contato);

            if($resultadoValidacao->getErros()){
                Sessao::gravaErro($resultadoValidacao->getErros());
                $this->redirect('/contato/alterar/'.$_POST['id']);
            }

            $contatoDAO = new ContatoDAO();

            $contatoDAO->atualizar($Contato);

            Sessao::limpaFormulario();
            Sessao::limpaMensagem();
            Sessao::limpaErro();

            Sessao::gravaMensagem("Parabéns","Contato atualizado com sucesso!","success");
            $this->redirect('/contato');
        } else {
            $this->redirect('/login');
        }

    }

    public function excluir($params)
    {
        if ($this->verifyLogin() !== false) {
            $id = $params[0];

            $contatoDAO = new ContatoDAO();

            $contato = $contatoDAO->listar($id);

            if(!$contato){
                Sessao::gravaMensagem("Ops","Contato de código ".$id." inexistente.","error");
                $this->redirect('/contato');
            }

            self::setViewParam('contato',$contato);

            $this->render('/contato/excluir');

            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }
    }

    public function exclusao()
    {
        if ($this->verifyLogin() !== false) {
            $Contato = new Contato();
            $Contato->setIdContato($_POST['id']);

            $contatoDAO = new ContatoDAO();

            if(!$contatoDAO->excluir($Contato)){
                Sessao::gravaMensagem("Contato inexistente");
                $this->redirect('/contato');
            }

            Sessao::gravaMensagem("", "Contato excluido com sucesso!","success");

            $this->redirect('/contato');
        } else {
            $this->redirect('/login');
        }
    }

}
