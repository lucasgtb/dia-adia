<?php

namespace App\Controllers;

use App\Lib\Sessao;
use App\Models\DAO\UsuarioDAO;
use App\Models\Entidades\Usuario;

class PerfilController extends Controller {

    public function index() {

        $usuarioDAO = new UsuarioDAO();

        $usuario = $usuarioDAO->select("SELECT * FROM Usuario WHERE idUsuario = ".Sessao::retornaLogin()->getIdUsuario())->fetchObject(Usuario::class);

        self::setViewParam('usuario', $usuario);
        $this->render('perfil/index');
        Sessao::limpaMensagem();
    }

    public function atualizar()
    {

        if ($this->verifyLogin() !== false) {
            $usuarioDAO = new UsuarioDAO();
            $Usuario = $usuarioDAO->listar(Sessao::retornaLogin()->getIdUsuario());
            $foto = $_FILES["foto"];

            if(isset($_FILES["foto"]) && preg_match("/^image\/(pjpeg|jpeg|png|gif|bmp)$/", $foto["type"])){
                // Largura máxima em pixels
                $largura = 10000;
                // Altura máxima em pixels
                $altura = 10000;
                // Tamanho máximo do arquivo em bytes
                $tamanho = 9000000;

                $error = array();

                // Verifica se o arquivo é uma imagem
                if(!preg_match("/^image\/(pjpeg|jpeg|png|gif|bmp)$/", $foto["type"])){
                   $error[1] = "Isso não é uma imagem.";
                }

                // Pega as dimensões da imagem
                $dimensoes = getimagesize($foto["tmp_name"]);

                // Verifica se a largura da imagem é maior que a largura permitida
                if($dimensoes[0] > $largura) {
                    $error[2] = "A largura da imagem não deve ultrapassar ".$largura." pixels";
                }

                // Verifica se a altura da imagem é maior que a altura permitida
                if($dimensoes[1] > $altura) {
                    $error[3] = "Altura da imagem não deve ultrapassar ".$altura." pixels";
                }

                // Verifica se o tamanho da imagem é maior que o tamanho permitido
                if($foto["size"] > $tamanho) {
                    $error[4] = "A imagem deve ter no máximo ".$tamanho." bytes";
                }

                // Se não houver nenhum erro
                if (count($error) == 0) {

                    // Pega extensão da imagem
                    preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $foto["name"], $ext);

                    // Gera um nome único para a imagem
                    $nome_imagem = md5(uniqid(time())) . "." . $ext[1];

                    // Caminho de onde ficará a imagem
                    $caminho_imagem = "public/img/usuario/" . $nome_imagem;

                    // Faz o upload da imagem para seu respectivo caminho
                    move_uploaded_file($foto["tmp_name"], $caminho_imagem);
                }

                // Se houver mensagens de erro, exibe-as
                if (count($error) != 0) {
                    foreach ($error as $erro) {
                    Sessao::gravaMensagem("Ops","Houve erros no uploud da imagem: ".$erro,"warning");
                    }
                }else{
                    $fotoantiga = Sessao::retornaLogin()->getFoto();
                    if (!empty($fotoantiga)) {
                        unlink("public/img/usuario/".$fotoantiga);
                    }
                }
                if (!empty($nome_imagem)) {
                    $Usuario->setFoto($nome_imagem);
                }
            }

            if($_POST['nova_senha'] == ""){
                $Usuario->setSenha($_POST['senha']);
            }else{
                $Usuario->setSenha(password_hash($_POST['nova_senha'], PASSWORD_BCRYPT, ['cost' => 8]));
            }

            $Usuario->setIdUsuario($_POST['id']);
            $Usuario->setBaixa($_POST['baixa']);
            $Usuario->setMedia($_POST['media']);
            $Usuario->setAlta($_POST['alta']);
            //$Usuario->setSexo($_POST['sexo']);
            $Usuario->setTelefone($_POST['telefone']);
            //$Usuario->setDataCriacao();
            Sessao::gravaFormulario($_POST);

           // $usuarioValidador = new UsuarioValidador();
            //$resultadoValidacao = $usuarioValidador->validar($Usuario);

           // if($resultadoValidacao->getErros()){
            //    Sessao::gravaErro($resultadoValidacao->getErros());
            //    $this->redirect('/perfil/alterar/'.$_POST['id']);
           // }


            $usuarioDAO->atualizar($Usuario);
            Sessao::gravaLogin($Usuario);
            Sessao::gravaMensagem("Parabéns","Perfil atualizado com sucesso!","success");
            $this->redirect('/perfil');
        } else {
            $this->redirect('/login');
        }

    }

}
