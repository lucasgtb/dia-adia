<?php

namespace App\Controllers;

use App\Lib\Sessao;

use App\Models\DAO\TarefaDAO;
use App\Models\DAO\PrioridadeDAO;

use App\Models\Entidades\Tarefa;
use App\Models\Entidades\Prioridade;

class TarefaController extends Controller {

    public function index() {

    	//$lixeiraDAO = new TarefaDAO();

        //self::setViewParam('listaTarefa',$lixeiraDAO->listar());
        Sessao::limpaMensagem();

        $this->render('tarefa/index');



    }

    public function lixeira() {

        if ($this->verifyLogin() !== false) {
            $tarefaDAO = new TarefaDAO();
            $idUsuario = Sessao::retornaLogin()->getIdUsuario();

            $prioridadeDAO = new prioridadeDAO();
            self::setViewParam('prioridades', $prioridadeDAO->listar());

            self::setViewParam('listaLixeira', $tarefaDAO->select("SELECT * FROM Tarefa WHERE status = 0 AND idUsuario = {$idUsuario}")->fetchAll(\PDO::FETCH_CLASS, Tarefa::class));

            $this->render('tarefa/lixeira');


            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }

    }

    public function incluir() {

        if ($this->verifyLogin() !== false) {
            $prioridadeDAO = new prioridadeDAO();
            self::setViewParam('prioridades', $prioridadeDAO->listar());

            $this->render('tarefa/incluir');

            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }

    }

    public function edicao($id = null) {

        if ($this->verifyLogin() !== false) {
            if (!is_null($id)) {
                $id = is_array($id) ? $id[0] : $id;
                $tarefaDAO      = new TarefaDAO();
                $prioridadeDAO  = new prioridadeDAO();

                self::setViewParam('prioridades', $prioridadeDAO->listar());
                self::setViewParam('tarefa', $tarefaDAO->listar($id));
                Sessao::limpaMensagem();
                $this->render('tarefa/edicao');

            } else {
                Sessao::gravaMensagem("Ops","Tarefa não encontrada.","error");
                $this->redirect('/home');
                Sessao::limpaMensagem();
            }
        } else {
            $this->redirect('/login');
        }

    }

    public function cadastrar() {

        if ($this->verifyLogin() !== false) {
            $tarefaDAO  = new TarefaDAO();
            $tarefa     = new Tarefa();

            foreach ($_POST as $key => $value) {
                $method = 'set'.ucwords($key);
                if (method_exists(Tarefa::class, $method)) {
                    $tarefa->$method($value);
                }
            }

            $tarefa->setIdUsuario(Sessao::retornaLogin()->getIdUsuario());
            $tarefa->setStatus(1);
            $tarefa->setDataCriacao(date('Y-m-d H:i:s'));
            $tarefa->setDataTarefa($_POST['data'].' '.$_POST['hora']);

            try {
                $tarefaDAO->salvar($tarefa);

                Sessao::gravaMensagem("","Tarefa cadastrada com sucesso!","success");
                Sessao::limpaFormulario();
                $this->redirect('/home');
                Sessao::limpaMensagem();

            } catch (Exception $e) {
                Sessao::gravaFormulario($_POST);
                Sessao::gravaMensagem("Ops","Erro ao processar cadastro.","error");
                $this->redirect('/home');
                Sessao::limpaMensagem();
            }
        } else {
            $this->redirect('/login');
        }

    }

    public function editar() {

        if ($this->verifyLogin() !== false) {
            $tarefaDAO  = new TarefaDAO();
            $tarefa     = $tarefaDAO->listar($_POST['idTarefa']);

            foreach ($_POST as $key => $value) {
                $method = 'set'.ucwords($key);
                if (method_exists(Tarefa::class, $method)) {
                    $tarefa->$method($value);
                }
            }

            $tarefa->setDataTarefa($_POST['data'].' '.$_POST['hora']);

            try {
                $tarefaDAO->atualizar($tarefa);
                Sessao::gravaMensagem("","Tarefa editada com sucesso!","success");
                Sessao::limpaFormulario();

                $this->redirect('/home');
            } catch (Exception $e) {
                Sessao::gravaFormulario($_POST);

                Sessao::gravaMensagem("Ops","Erro ao editar tarefa.","error");

                $this->redirect('/home');
            }

            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }

    }

    public function exclusao($id = null) {

        if ($this->verifyLogin() !== false) {
            if (!is_null($id)) {
                $id = is_array($id) ? $id[0] : $id;
                $tarefaDAO  = new TarefaDAO();

                try {
                    $tarefaDAO->excluir($tarefaDAO->listar($id));

                    Sessao::gravaMensagem("","Tarefa excluída permanentemente!","success");
                    $this->redirect('/tarefa/lixeira');
                    Sessao::limpaMensagem();
                } catch (Exception $e) {
                    Sessao::gravaMensagem("Ops","Erro ao excluir tarefa.","error");
                    $this->redirect('/lixeira');
                }


            } else {
                $tarefaDAO  = new TarefaDAO();
                $idUsuario  = Sessao::retornaLogin()->getIdUsuario();

                try {
                    foreach ($tarefaDAO->select("SELECT * FROM Tarefa WHERE status = 0 AND idUsuario = {$idUsuario}")->fetchAll(\PDO::FETCH_CLASS, Tarefa::class) as $tarefa) {
                        $tarefaDAO->excluir($tarefa);
                    }

                    Sessao::gravaMensagem("","Tarefas excluídas permanentemente!","success");

                    $this->redirect('/tarefa/lixeira');
                    Sessao::limpaMensagem();
                } catch (Exception $e) {

                    Sessao::gravaMensagem("Ops","Algumas tarefas não puderam ser excluídas.","error");
                    $this->redirect('/lixeira');
                }

            }
        } else {
            $this->redirect('/login');
        }

    }

    public function excluir($id = null) {

        if ($this->verifyLogin() !== false) {
            if (!is_null($id)) {
                $id = is_array($id) ? $id[0] : $id;
                $tarefaDAO  = new TarefaDAO();
                $tarefa     = $tarefaDAO->listar($id);
                $tarefa->setStatus(0);

                try {
                    $tarefaDAO->atualizar($tarefa);

                    Sessao::gravaMensagem("","Tarefa movida para a lixeira!","success");
                    $this->redirect('/home');
                    Sessao::limpaMensagem();

                } catch (Exception $e) {

                    Sessao::gravaMensagem("Ops","Erro ao excluir tarefa.","error");
                    $this->redirect('/home');
                }

            } else {

                Sessao::gravaMensagem("Ops","Tarefa não encontrada.","error");
                $this->redirect('/home');
            }
        } else {
            $this->redirect('/login');
        }

    }

    public function deletar($params)
    {
        if ($this->verifyLogin() !== false) {
            $id = $params[0];

            $tarefaDAO  = new TarefaDAO();
            $idUsuario  = Sessao::retornaLogin()->getIdUsuario();

            if(is_null($params)){
                $tarefa = $tarefaDAO->select("SELECT * FROM Tarefa WHERE status = 0 AND idUsuario = {$idUsuario}")->fetchAll(\PDO::FETCH_CLASS, Tarefa::class);
            }else{
                $tarefa  = $tarefaDAO->select("SELECT * FROM Tarefa WHERE idTarefa = {$id} AND idUsuario = {$idUsuario}")->fetchObject(Tarefa::class); // controle para que sejam excluidas somente tarefas do ususário
            }

            if(!$tarefa){
                Sessao::gravaMensagem("Ops","Tarefa de código ".$id." inexistente.","error");

                $this->redirect('/lixeira');
            }

            self::setViewParam('tarefa',$tarefa);

            $this->render('/tarefa/excluir');

            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }
    }



    public function restaurar($id = null) {

        if ($this->verifyLogin() !== false) {
            if (!is_null($id)) {
                $id = is_array($id) ? $id[0] : $id;
                $tarefaDAO  = new TarefaDAO();
                $tarefa     = $tarefaDAO->listar($id);
                $tarefa->setStatus(1);

                try {
                    $tarefaDAO->atualizar($tarefa);

                    Sessao::gravaMensagem("","Tarefa restaurada com sucesso!","success");

                    $this->redirect('/tarefa/lixeira');
                    //Sessao::limpaMensagem();
                } catch (Exception $e) {
                    Sessao::gravaMensagem('Erro ao restaurar tarefa.', 'alert-danger');
                    $this->redirect('/tarefa/lixeira');
                }

                Sessao::limpaMensagem();
            } else {
                Sessao::gravaMensagem('Tarefa não encontrada.', 'alert-danger');
                $this->redirect('/home');
                Sessao::limpaMensagem();
            }
        } else {
            $this->redirect('/login');
        }

    }

    public function desfazer($id = null) {

        if ($this->verifyLogin() !== false) {
            if (!is_null($id)) {
                $id = is_array($id) ? $id[0] : $id;
                $tarefaDAO  = new TarefaDAO();
                $tarefa     = $tarefaDAO->listar($id);
                $tarefa->setStatus(1);

                try {
                    $tarefaDAO->atualizar($tarefa);
                    Sessao::gravaMensagem("","Tarefa desfeita com sucesso.","success");
                    Sessao::limpaMensagem();
                    $this->redirect('/home');
                    Sessao::limpaMensagem();
                } catch (Exception $e) {
                    Sessao::gravaMensagem('Erro ao desfazer status da tarefa.', 'alert-danger');
                    $this->redirect('/home');
                }

                Sessao::limpaMensagem();
            } else {
                Sessao::gravaMensagem('Tarefa não encontrada.', 'alert-danger');
                $this->redirect('/home');
                Sessao::limpaMensagem();
            }
            Sessao::limpaMensagem();
        } else {
            $this->redirect('/login');
        }

    }

    public function concluir($id = null) {

        if ($this->verifyLogin() !== false) {
            if (!is_null($id)) {
                $id = is_array($id) ? $id[0] : $id;
                $tarefaDAO  = new TarefaDAO();
                $tarefa     = $tarefaDAO->listar($id);
                $tarefa->setStatus(2);

                try {
                    $tarefaDAO->atualizar($tarefa);

                    Sessao::gravaMensagem("","Tarefa concluída com sucesso.","success");

                    $this->redirect('/home');
                } catch (Exception $e) {
                    Sessao::gravaMensagem('Erro ao concluir tarefa.', 'alert-danger');
                    $this->redirect('/home');
                }
                Sessao::limpaMensagem();
            } else {
                Sessao::gravaMensagem('Tarefa não encontrada.', 'alert-danger');
                $this->redirect('/home');
                Sessao::limpaMensagem();
            }
        } else {
            $this->redirect('/login');
        }

    }

    public function tarefasDia($data) {

        if ($this->verifyLogin() !== false) {
            $data = is_array($data) ? $data[0] : date('Y-m-d');

            $tarefaDAO      = new TarefaDAO();
            $prioridadeDAO  = new PrioridadeDAO();

            $idUsuario      = Sessao::retornaLogin()->getIdUsuario();
            $tarefas        = $tarefaDAO->select("SELECT * FROM Tarefa WHERE DATE(dataTarefa) = '{$data}' AND idUsuario = {$idUsuario} AND status <> 0  ORDER BY dataTarefa")->fetchAll(\PDO::FETCH_CLASS, Tarefa::class);
            $prioridades    = $prioridadeDAO->listar();

            // foreach ($tarefas as $tarefa) {
            //     $return[] = new \stdClass();
            //     foreach (class_methods($tarefa) as $method) {
            //         if (strpos($method, 'get') !== false) {
            //             $return[count($return) - 1]->{explode('get', $method)[1]} = $tarefa->$method();
            //         }
            //     }
            // }

            self::setViewParam('tarefas', $tarefas);
            self::setViewParam('prioridades', $prioridades);
            // echo "SELECT * FROM Tarefa WHERE DATE(dataTarefa) = '{$data}' AND idUsuario = {$idUsuario} ORDER BY dataTarefa";
            $this->renderViewOnly('tarefa/tarefas-dia');

        } else {
            $this->redirect('/login');
        }

    }

}
