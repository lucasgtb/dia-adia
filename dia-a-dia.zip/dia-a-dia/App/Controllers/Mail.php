<?php

return [

   'driver' => env('MAIL_DRIVER', 'smtp'),
   'host' => env('MAIL_HOST', 'lucasbaur.com.br'),
   'port' => env('MAIL_PORT', 465),
   'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'dia-a-dia@lucasbaur.com.br'),
        'name' => env('MAIL_FROM_NAME', 'Dia-s2-dia'),
    ],

    'encryption' => env('MAIL_ENCRYPTION', 'tls'),
    'username' => env('dia-a-dia@lucasbaur.com.br'),
    'password' => env('123456'),
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => [
        'theme' => 'default',

        'paths' => [
            resource_path('views/vendor/mail'),
        ],
    ],

];

/*
MAIL_DRIVER=smtp
MAIL_HOST=lucasbaur.com.br
MAIL_PORT=465
MAIL_USERNAME=dia-a-dia@lucasbaur.com.br
MAIL_PASSWORD=123456
MAIL_ENCRYPTION=tls
*/
?>
