<?php

namespace App\Controllers;
use App\Lib\Sessao;
use App\Models\DAO\ContatoDAO;
use App\Models\Entidades\Contato;
use App\Models\DAO\UsuarioDAO;
use App\Models\Entidades\Usuario;

class HomeController extends Controller
{
    public function index()
    {
        if ($this->verifyLogin() !== false) {
            $contatoDAO = new ContatoDAO();
            self::setViewParam('listaAniversarioContato', $contatoDAO->select("SELECT * FROM Contato WHERE MONTH(dataNascimento) = MONTH(NOW()) AND idUsuario = ".Sessao::retornaLogin()->getIdUsuario()." order by DAY(dataNascimento) ASC")->fetchAll(\PDO::FETCH_CLASS, Contato::class));
            $this->render('home/index');
        } else {
            $this->redirect('/login');
        }
    }

    public function inicio()
    {
        $this->index();
    }


}
