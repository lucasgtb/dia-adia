<?php

namespace App\Controllers;

use App\Lib\Sessao;
use App\Models\DAO\TarefaDAO;
use App\Models\Entidades\Tarefa;
use App\Models\DAO\ContatoDAO;
use App\Models\Entidades\Contato;
use App\Models\DAO\PrioridadeDAO;
use App\Models\Entidades\Prioridade;

class CalendarioController extends Controller {

    public function index() {

        if ($this->verifyLogin() !== false) {
        	  $tarefaDAO = new TarefaDAO();
            self::setViewParam('listaEventos', $tarefaDAO->select("SELECT * FROM Tarefa WHERE idUsuario = ".Sessao::retornaLogin()->getIdUsuario())->fetchAll(\PDO::FETCH_CLASS, Tarefa::class));
            $contatoDAO = new ContatoDAO();
            self::setViewParam('listaAniversarioContato', $contatoDAO->select("SELECT * FROM Contato WHERE idUsuario = ".Sessao::retornaLogin()->getIdUsuario())->fetchAll(\PDO::FETCH_CLASS, Contato::class));

            $prioridadeDAO  = new prioridadeDAO();
            self::setViewParam('prioridades', $prioridadeDAO->listar());

            Sessao::limpaMensagem();
            $this->render('calendario/index');

        } else {
            $this->redirect('/login');
        }

    }

}
