<?php

namespace App\Controllers;

use App\Lib\Sessao;

class ManutencaoController extends Controller
{
    public function index()
    {
        $this->renderViewOnly('manutencao/index');
    }
}
