<?php

namespace App\Models\DAO;

use App\Models\Entidades\Usuario;

class UsuarioDAO extends BaseDAO
{
    public  function listar($id = null)
    {
        if($id) {
            $resultado = $this->select(
                "SELECT * FROM Usuario WHERE idUsuario = $id"
            );

            return $resultado->fetchObject(Usuario::class);
        }else{
            $resultado = $this->select(
                'SELECT * FROM Usuario'
            );
            return $resultado->fetchAll(\PDO::FETCH_CLASS, Usuario::class);
        }

        return false;
    }

    public  function salvar(Usuario $usuario)
    {
        try {

            $idUsuario      = $usuario->getIdUsuario();
            $nome           = $usuario->getNome();
            $login          = $usuario->getLogin();
            $email          = $usuario->getEmail();
            $senha          = $usuario->getSenha();
            $dataNascimento = $usuario->getDataNascimento()->format('Y-m-d');
            $sexo           = $usuario->getSexo();
            $telefone       = $usuario->getTelefone();
            $dataCriacao    = $usuario->getDataCriacao()->format('Y-m-d');
            $alta           = $usuario->getAlta();
            $media          = $usuario->getMedia();
            $baixa          = $usuario->getBaixa();

            return $this->insert(
                'Usuario',
                ":nome, :login, :email, :senha, :dataNascimento, :sexo, :telefone, :dataCriacao, :baixa, :media, :alta",
                [
                    ':nome'             => $nome,
                    ':login'            => $login,
                    ':email'            => $email,
                    ':senha'            => $senha,
                    ':dataNascimento'   => $dataNascimento,
                    ':sexo'             => $sexo,
                    ':telefone'         => $telefone,
                    ':dataCriacao'      => $dataCriacao,
                    ':baixa'            => $baixa,
                    ':media'            => $media,
                    ':alta'             => $alta
                ]
            );

        }catch (\Exception $e){
            throw new \Exception("Erro na gravação de dados.".$e, 500);
        }
    }

    public  function atualizar(Usuario $usuario)
    {
        try {

            $idUsuario      = $usuario->getIdUsuario();
            //$nome           = $usuario->getNome();
            //$login          = $usuario->getLogin();
            //$email          = $usuario->getEmail();
            $senha          = $usuario->getSenha();
            //$dataNascimento = $usuario->getDataNascimento()->format('Y-m-d');
            //$sexo           = $usuario->getSexo();
            $telefone       = $usuario->getTelefone();
            //$dataCriacao    = $usuario->getDataCriacao()->format('Y-m-d');
            $foto           = $usuario->getFoto();
            $alta           = $usuario->getAlta();
            $media          = $usuario->getMedia();
            $baixa          = $usuario->getBaixa();


            /*
             'Usuario',
                "nome = :nome, login = :login, email = :email, senha = :senha, dataNascimento = :dataNascimento, sexo = :sexo, telefone = :telefone, dataCriacao = :dataCriacao, foto = :foto",
             */

            return $this->update(
                'Usuario',
                "senha = :senha, telefone = :telefone, foto = :foto,  baixa = :baixa, media = :media, alta = :alta",
                [
                    ':idUsuario'        => $idUsuario,
                    //':nome'             => $nome,
                    //':login'            => $login,
                    //':email'            => $email,
                    ':senha'            => $senha,
                    //':dataNascimento'   => $dataNascimento,
                    //':sexo'             => $sexo,
                    ':telefone'         => $telefone,
                    //':dataCriacao'      => $dataCriacao,
                    ':foto'             => $foto,
                    ':baixa'            => $baixa,
                    ':media'            => $media,
                    ':alta'             => $alta
                ],
                "idUsuario = :idUsuario"
            );

            unlink("public/img/usuario/".$foto);

        }catch (\Exception $e){
            throw new \Exception("Erro na gravação de dados.".$e, 500);
        }
    }

    public function excluir(Usuario $usuario)
    {
        try {
            $id = $usuario->getIdUsuario();

            return $this->delete('Usuario',"idUsuario = $id");

        }catch (Exception $e){

            throw new \Exception("Erro ao deletar", 500);
        }
    }
}
