<?php

namespace App\Models\DAO;

use App\Models\Entidades\Contato;

class ContatoDAO extends BaseDAO
{
    public  function listar($id = null)
    {
        if($id) {
            $resultado = $this->select(
                "SELECT * FROM Contato WHERE idContato = $id"
            );

            return $resultado->fetchObject(Contato::class);
        }else{
            $resultado = $this->select(
                'SELECT * FROM Contato'
            );
            return $resultado->fetchAll(\PDO::FETCH_CLASS, Contato::class);
        }

        return false;
    }

    public  function salvar(Contato $contato)
    {
        try {

            $nome           = $contato->getNome();
            $idUsuario      = $contato->getIdUsuario();
            $email          = $contato->getEmail();
            $datanascimento = $contato->getDataNascimento()->format('Y-m-d');
            $telefone       = $contato->getTelefone();

            return $this->insert(
                'Contato',
                ":nome, :email, :dataNascimento, :telefone, :idUsuario",
                [
                    ':nome'             => $nome,
                    ':idUsuario'        => $idUsuario,
                    ':email'            => $email,
                    ':dataNascimento'   => $datanascimento,
                    ':telefone'         => $telefone
                ]
            );

        }catch (\Exception $e){
            throw new \Exception("Erro na gravação de dados.", 500);
        }
    }

    public  function atualizar(Contato $contato)
    {
        try {

            $id             = $contato->getIdContato();
            $idUsuario      = $contato->getIdUsuario();
            $nome           = $contato->getNome();
            $email          = $contato->getEmail();
            $datanascimento = $contato->getDataNascimento()->format('Y-m-d');
            $telefone       = $contato->getTelefone();

            return $this->update(
                'Contato',
                "nome = :nome, email = :email, datanascimento = :dataNascimento, telefone = :telefone, idUsuario = :idUsuario",
                [
                    ':idContato'        => $id,
                    ':idUsuario'        => $idUsuario,
                    ':nome'             => $nome,
                    ':email'            => $email,
                    ':dataNascimento'   => $datanascimento,
                    ':telefone'         => $telefone
                ],
                "idContato = :idContato"
            );

        }catch (\Exception $e){
            throw new \Exception("Erro na gravação de dados.", 500);
        }
    }

    public function excluir(Contato $contato)
    {
        try {
            $id = $contato->getIdContato();

            return $this->delete('Contato',"idContato = $id");

        }catch (Exception $e){

            throw new \Exception("Erro ao deletar", 500);
        }
    }
}
