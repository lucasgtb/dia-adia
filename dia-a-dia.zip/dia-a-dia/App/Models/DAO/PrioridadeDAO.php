<?php

namespace App\Models\DAO;

use App\Models\Entidades\Prioridade;

class PrioridadeDAO extends BaseDAO
{
    public  function listar($id = null)
    {
        if($id) {
            $resultado = $this->select(
                "SELECT * FROM Prioridade WHERE idPrioridade = $id"
            );

            return $resultado->fetchObject(Prioridade::class);
        }else{
            $resultado = $this->select(
                'SELECT * FROM Prioridade'
            );
            return $resultado->fetchAll(\PDO::FETCH_CLASS, Prioridade::class);
        }

        return false;
    }

    public  function salvar(Prioridade $prioridade)
    {
        try {

            $nome   = $prioridade->getNome();
            $cor    = $prioridade->getCor();

            return $this->insert(
                'Prioridade',
                ":nome, :cor",
                [
                    ':nome' => $nome,
                    ':cor'  => $cor
                ]
            );

        }catch (\Exception $e){
            throw new \Exception("Erro na gravação de dados.", 500);
        }
    }

    public  function atualizar(Prioridade $prioridade)
    {
        try {

            $id     = $prioridade->getIdPrioridade();
            $nome   = $prioridade->getNome();
            $cor    = $prioridade->getCor();

            return $this->update(
                'Prioridade',
                "nome = :nome, cor = :cor",
                [
                    ':idPrioridade' => $id,
                    ':nome'         => $nome,
                    ':cor'          => $cor
                ],
                "idPrioridade = :idPrioridade"
            );

        }catch (\Exception $e){
            throw new \Exception("Erro na gravação de dados.", 500);
        }
    }

    public function excluir(Prioridade $prioridade)
    {
        try {
            $id = $prioridade->getIdPrioridade();

            return $this->delete('Prioridade',"idPrioridade = $id");

        }catch (Exception $e){

            throw new \Exception("Erro ao deletar", 500);
        }
    }
}
