<?php

namespace App\Models\DAO;

use App\Models\Entidades\Tarefa;

class TarefaDAO extends BaseDAO
{
    public  function listar($id = null)
    {
        if($id) {
            $resultado = $this->select(
                "SELECT * FROM Tarefa WHERE idTarefa = $id"
            );

            return $resultado->fetchObject(Tarefa::class);
        }else{
            $resultado = $this->select(
                'SELECT * FROM Tarefa'
            );
            return $resultado->fetchAll(\PDO::FETCH_CLASS, Tarefa::class);
        }

        return false;
    }

    public  function salvar(Tarefa $tarefa)
    {
        try {

            $idUsuario      = $tarefa->getIdUsuario();
            $idPrioridade   = $tarefa->getIdPrioridade();
            $titulo         = $tarefa->getTitulo();
            $descricao      = $tarefa->getDescricao();
            $dataTarefa     = $tarefa->getDataTarefa()->format('Y-m-d H:i:s');
            $dataCriacao    = $tarefa->getDataCriacao()->format('Y-m-d H:i:s');
            $status         = $tarefa->getStatus();
            $local          = $tarefa->getLocal();
            $alerta         = $tarefa->getAlerta();
            $textoAlerta    = $tarefa->getTextoAlerta();

            return $this->insert(
                'Tarefa',
                ":idUsuario, :idPrioridade, :titulo, :descricao, :dataTarefa, :dataCriacao, :status, :local, :alerta, :textoAlerta",
                [
                    ':idUsuario'    => $idUsuario,
                    ':idPrioridade' => $idPrioridade,
                    ':titulo'       => $titulo,
                    ':descricao'    => $descricao,
                    ':dataTarefa'   => $dataTarefa,
                    ':dataCriacao'  => $dataCriacao,
                    ':status'       => $status,
                    ':local'        => $local,
                    ':alerta'       => $alerta,
                    ':textoAlerta'  => $textoAlerta
                ]
            );

        }catch (\Exception $e){
            throw new \Exception($e, 500);
        }
    }

    public  function atualizar(Tarefa $tarefa)
    {
        try {

            $idTarefa       = $tarefa->getIdTarefa();
            $idUsuario      = $tarefa->getIdUsuario();
            $idPrioridade   = $tarefa->getIdPrioridade();
            $titulo         = $tarefa->getTitulo();
            $descricao      = $tarefa->getDescricao();
            $dataTarefa     = $tarefa->getDataTarefa()->format('Y-m-d H:i:s');
            $dataCriacao    = $tarefa->getDataCriacao()->format('Y-m-d H:i:s');
            $status         = $tarefa->getStatus();
            $local          = $tarefa->getLocal();
            $alerta         = $tarefa->getAlerta();
            $textoAlerta    = $tarefa->getTextoAlerta();

            return $this->update(
                'Tarefa',
                "idTarefa = :idTarefa, idUsuario = :idUsuario, idPrioridade = :idPrioridade, titulo = :titulo, descricao = :descricao, dataTarefa = :dataTarefa, dataCriacao = :dataCriacao, status = :status, local = :local, alerta = :alerta, textoAlerta = :textoAlerta",
                [
                    ':idTarefa'     => $idTarefa,
                    ':idUsuario'    => $idUsuario,
                    ':idPrioridade' => $idPrioridade,
                    ':titulo'       => $titulo,
                    ':descricao'    => $descricao,
                    ':dataTarefa'   => $dataTarefa,
                    ':dataCriacao'  => $dataCriacao,
                    ':status'       => $status,
                    ':local'        => $local,
                    ':alerta'       => $alerta,
                    ':textoAlerta'  => $textoAlerta
                ],
                "idTarefa = :idTarefa"
            );

        }catch (\Exception $e){
            throw new \Exception($e, 500);
        }
    }

    public function excluir(Tarefa $tarefa)
    {
        try {
            $id = $tarefa->getIdTarefa();

            return $this->delete('Tarefa',"idTarefa = $id");

        }catch (Exception $e){

            throw new \Exception("Erro ao deletar", 500);
        }
    }

}
