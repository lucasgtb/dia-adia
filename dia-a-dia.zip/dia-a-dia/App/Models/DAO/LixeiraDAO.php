<?php

namespace App\Models\DAO;

use App\Models\Entidades\Tarefa;

class TarefaDAO extends BaseDAO
{
    public  function listar($id = null)
    {
        if($id) {
            $resultado = $this->select(
                "SELECT * FROM Tarefa WHERE status = 0"
            );

            return $resultado->fetchObject(Tarefa::class);
        }else{
            $resultado = $this->select(
                'SELECT * FROM Tarefa'
            );
            return $resultado->fetchAll(\PDO::FETCH_CLASS, Tarefa::class);
        }

        return false;
    }

}
