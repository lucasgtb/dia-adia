<?php

namespace App\Models\Validacao;

use \App\Models\Validacao\ResultadoValidacao;
use \App\Models\Entidades\Contato;

class ContatoValidador{

    public function validar(Contato $contato)
    {
        $resultadoValidacao = new ResultadoValidacao();

        if(empty($contato->getNome()))
        {
            $resultadoValidacao->addErro('nome',"Nome: Este campo não pode ser vazio");
        }
        
        if(empty($contato->getEmail()))
        {
            $resultadoValidacao->addErro('email',"Email: Este campo não pode ser vazio");
        }

        if(empty($contato->getDataNascimento()))
        {
            $resultadoValidacao->addErro('dataNascimento',"Data de Nascimento: Este campo não pode ser vazio");
        }

        if(empty($contato->getTelefone()))
        {
            $resultadoValidacao->addErro('telefone',"Telefone: Este campo não pode ser vazio");
        }

        return $resultadoValidacao;
    }
}