<?php

namespace App\Models\Entidades;

class Tarefa {

    private $idTarefa;
    private $idUsuario;
    private $idPrioridade;
    private $titulo;
    private $descricao;
    private $dataTarefa;
    private $dataCriacao;
    private $status;
    private $local;
    private $alerta;
    private $textoAlerta;


    /**
     * Get the value of Id Tarefa
     *
     * @return mixed
     */
    public function getIdTarefa()
    {
        return $this->idTarefa;
    }

    /**
     * Set the value of Id Tarefa
     *
     * @param mixed idTarefa
     *
     * @return self
     */
    public function setIdTarefa($idTarefa)
    {
        $this->idTarefa = $idTarefa;

        return $this;
    }

    /**
     * Get the value of Id Usuario
     *
     * @return mixed
     */
    public function getIdUsuario()
    {
        return $this->idUsuario;
    }

    /**
     * Set the value of Id Usuario
     *
     * @param mixed idUsuario
     *
     * @return self
     */
    public function setIdUsuario($idUsuario)
    {
        $this->idUsuario = $idUsuario;

        return $this;
    }

    /**
     * Get the value of Titulo
     *
     * @return mixed
     */
    public function getTitulo()
    {
        return $this->titulo;
    }

    /**
     * Set the value of Titulo
     *
     * @param mixed titulo
     *
     * @return self
     */
    public function setTitulo($titulo)
    {
        $this->titulo = $titulo;

        return $this;
    }

    /**
     * Get the value of Descricao
     *
     * @return mixed
     */
    public function getDescricao()
    {
        return $this->descricao;
    }

    /**
     * Set the value of Descricao
     *
     * @param mixed descricao
     *
     * @return self
     */
    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;

        return $this;
    }

    /**
     * Get the value of Data Tarefa
     *
     * @return mixed
     */
    public function getDataTarefa()
    {
        return new \DateTime($this->dataTarefa);
        // return \DateTime::createFromFormat('d/m/Y', $this->dataTarefa) ? \DateTime::createFromFormat('d/m/Y', $this->dataTarefa) : new \DateTime($dataTarefa);
        // return $this->dataTarefa;
    }

    /**
     * Set the value of Data Tarefa
     *
     * @param mixed dataTarefa
     *
     * @return self
     */
    public function setDataTarefa($dataTarefa)
    {
        $this->dataTarefa = $dataTarefa;

        return $this;
    }

    /**
     * Get the value of Data Criacao
     *
     * @return mixed
     */
    public function getDataCriacao()
    {
        return new \DateTime($dataCriacao);
    }

    /**
     * Set the value of Data Criacao
     *
     * @param mixed dataCriacao
     *
     * @return self
     */
    public function setDataCriacao($dataCriacao)
    {
        $this->dataCriacao = $dataCriacao;

        return $this;
    }

    /**
     * Get the value of Status
     *
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set the value of Status
     *
     * @param mixed status
     *
     * @return self
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }


    /**
     * Get the value of Id Prioridade
     *
     * @return mixed
     */
    public function getIdPrioridade()
    {
        return $this->idPrioridade;
    }

    /**
     * Set the value of Id Prioridade
     *
     * @param mixed idPrioridade
     *
     * @return self
     */
    public function setIdPrioridade($idPrioridade)
    {
        $this->idPrioridade = $idPrioridade;

        return $this;
    }


    /**
     * Get the value of Local
     *
     * @return mixed
     */
    public function getLocal()
    {
        return $this->local;
    }

    /**
     * Set the value of Local
     *
     * @param mixed local
     *
     * @return self
     */
    public function setLocal($local)
    {
        $this->local = $local;

        return $this;
    }

    /**
     * Get the value of Alerta
     *
     * @return mixed
     */
    public function getAlerta()
    {
        return $this->alerta;
    }

    /**
     * Set the value of Alerta
     *
     * @param mixed alerta
     *
     * @return self
     */
    public function setAlerta($alerta)
    {
        $this->alerta = $alerta;

        return $this;
    }

    /**
     * Get the value of Texto Alerta
     *
     * @return mixed
     */
    public function getTextoAlerta()
    {
        return $this->textoAlerta;
    }

    /**
     * Set the value of Texto Alerta
     *
     * @param mixed textoAlerta
     *
     * @return self
     */
    public function setTextoAlerta($textoAlerta)
    {
        $this->textoAlerta = $textoAlerta;

        return $this;
    }

}
