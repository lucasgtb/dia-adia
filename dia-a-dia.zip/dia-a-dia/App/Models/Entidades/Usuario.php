<?php

namespace App\Models\Entidades;

class Usuario {

    private $idUsuario;
    private $nome;
    private $login;
    private $email;
    private $senha;
    private $dataNascimento;
    private $sexo;
    private $ddd;
    private $telefone;
    private $dataCriacao;
    private $foto;
    private $alta;
    private $media;
    private $baixa;

    /**
    * Get the value of Id Usuario
    *
    * @return mixed
    */
    public function getIdUsuario()
    {
        return $this->idUsuario;
    }

    /**
    * Set the value of Id Usuario
    *
    * @param mixed idUsuario
    *
    * @return self
    */
    public function setIdUsuario($idUsuario)
    {
        $this->idUsuario = $idUsuario;

        return $this;
    }

    /**
    * Get the value of Nome
    *
    * @return mixed
    */
    public function getNome()
    {
        return $this->nome;
    }

    /**
    * Set the value of Nome
    *
    * @param mixed nome
    *
    * @return self
    */
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    /**
    * Get the value of Login
    *
    * @return mixed
    */
    public function getLogin()
    {
        return $this->login;
    }

    /**
    * Set the value of Login
    *
    * @param mixed login
    *
    * @return self
    */
    public function setLogin($login)
    {
        $this->login = $login;

        return $this;
    }

    /**
    * Get the value of Email
    *
    * @return mixed
    */
    public function getEmail()
    {
        return $this->email;
    }

    /**
    * Set the value of Email
    *
    * @param mixed email
    *
    * @return self
    */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
    * Get the value of Senha
    *
    * @return mixed
    */
    public function getSenha()
    {
        return $this->senha;
    }

    /**
    * Set the value of Senha
    *
    * @param mixed senha
    *
    * @return self
    */
    public function setSenha($senha)
    {
        $this->senha = $senha;

        return $this;
    }

    /**
    * Get the value of Data Nascimento
    *
    * @return mixed
    */
    public function getDataNascimento()
    {
        return \DateTime::createFromFormat('d/m/Y', $this->dataNascimento) ? \DateTime::createFromFormat('d/m/Y', $this->dataNascimento) : new \DateTime($this->dataNascimento);
    }

    /**
    * Set the value of Data Nascimento
    *
    * @param mixed dataNascimento
    *
    * @return self
    */
    public function setDataNascimento($dataNascimento)
    {
        $this->dataNascimento = $dataNascimento;

        return $this;
    }

    /**
    * Get the value of Sexo
    *
    * @return mixed
    */
    public function getSexo()
    {
        return $this->sexo;
    }

    /**
    * Set the value of Sexo
    *
    * @param mixed sexo
    *
    * @return self
    */
    public function setSexo($sexo)
    {
        $this->sexo = $sexo;

        return $this;
    }

    /**
    * Get the value of Ddd
    *
    * @return mixed
    */
    public function getDdd()
    {
        return $this->ddd;
    }

    /**
    * Set the value of Ddd
    *
    * @param mixed ddd
    *
    * @return self
    */
    public function setDdd($ddd)
    {
        $this->ddd = $ddd;

        return $this;
    }

    /**
    * Get the value of Telefone
    *
    * @return mixed
    */
    public function getTelefone()
    {
        return $this->telefone;
    }

    /**
    * Set the value of Telefone
    *
    * @param mixed telefone
    *
    * @return self
    */
    public function setTelefone($telefone)
    {
        $this->telefone = $telefone;

        return $this;
    }

    /**
    * Get the value of Data Criacao
    *
    * @return mixed
    */
    public function getDataCriacao()
    {
        return new \DateTime($this->dataCriacao);
    }

    /**
    * Set the value of Data Criacao
    *
    * @param mixed dataCriacao
    *
    * @return self
    */
    public function setDataCriacao($dataCriacao)
    {
        $this->dataCriacao = $dataCriacao;

        return $this;
    }

    /**
    * Get the value of Foto
    *
    * @return mixed
    */
    public function getFoto()
    {
        return $this->foto;
    }

    /**
    * Set the value of Foto
    *
    * @param mixed foto
    *
    * @return self
    */
    public function setFoto($foto)
    {
        $this->foto = $foto;

        return $this;
    }

    /**
    * Get the value of Alta
    *
    * @return mixed
    */
    public function getAlta() {
        return $this->alta;
    }

    /**
    * Set the value of Alta
    *
    * @param mixed alta
    *
    * @return self
    */
    public function setAlta($alta) {
        $this->alta = $alta;

        return $this;
    }

    /**
    * Get the value of Media
    *
    * @return mixed
    */
    public function getMedia() {
        return $this->media;
    }

    /**
    * Set the value of Media
    *
    * @param mixed Media
    *
    * @return self
    */
    public function setMedia($media) {
        $this->media = $media;

        return $this;
    }

    /**
    * Get the value of Baixa
    *
    * @return mixed
    */
    public function getBaixa() {
        return $this->baixa;
    }

    /**
    * Set the value of Baixa
    *
    * @param mixed Baixa
    *
    * @return self
    */
    public function setBaixa($baixa) {
        $this->baixa = $baixa;

        return $this;
    }

}
