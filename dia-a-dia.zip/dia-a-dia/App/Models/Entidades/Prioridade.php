<?php

namespace App\Models\Entidades;

class Prioridade {

    private $idPrioridade;
    private $nome;
    private $cor;


    /**
    * Get the value of Id Prioridade
    *
    * @return mixed
    */
    public function getIdPrioridade() {
        return $this->idPrioridade;
    }

    /**
    * Set the value of Id Prioridade
    *
    * @param mixed idPrioridade
    *
    * @return self
    */
    public function setIdPrioridade($idPrioridade) {
        $this->idPrioridade = $idPrioridade;

        return $this;
    }

    /**
    * Get the value of Nome
    *
    * @return mixed
    */
    public function getNome() {
        return $this->nome;
    }

    /**
    * Set the value of Nome
    *
    * @param mixed nome
    *
    * @return self
    */
    public function setNome($nome) {
        $this->nome = $nome;

        return $this;
    }

    /**
    * Get the value of Cor
    *
    * @return mixed
    */
    public function getCor() {
        return $this->cor;
    }

    /**
    * Set the value of Cor
    *
    * @param mixed cor
    *
    * @return self
    */
    public function setCor($cor) {
        $this->cor = $cor;

        return $this;
    }

}
