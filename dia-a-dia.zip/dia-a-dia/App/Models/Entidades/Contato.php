<?php

namespace App\Models\Entidades;

use DateTime;

class Contato
{
    private $idContato;
    private $nome;
    private $email;
    private $dataNascimento;
    private $telefone;
    private $idUsuario;



/**
* Get the value of Id Contato
*
* @return mixed
*/
public function getIdContato() {
   return $this->idContato;
}

/**
* Set the value of Id Contato
*
* @param mixed idContato
*
* @return self
*/
public function setIdContato($idContato) {
    $this->idContato = $idContato;

    return $this;
}

/**
* Get the value of Nome
*
* @return mixed
*/
public function getNome() {
   return $this->nome;
}

/**
* Set the value of Nome
*
* @param mixed nome
*
* @return self
*/
public function setNome($nome) {
    $this->nome = $nome;

    return $this;
}

/**
* Get the value of Email
*
* @return mixed
*/
public function getEmail() {
   return $this->email;
}

/**
* Set the value of Email
*
* @param mixed email
*
* @return self
*/
public function setEmail($email) {
    $this->email = $email;

    return $this;
}

/**
* Get the value of Data Nascimento
*
* @return mixed
*/
public function getDataNascimento() {
   return \DateTime::createFromFormat('d/m/Y', $this->dataNascimento) ? \DateTime::createFromFormat('d/m/Y', $this->dataNascimento) : new \DateTime($this->dataNascimento);
}

/**
* Set the value of Data Nascimento
*
* @param mixed dataNascimento
*
* @return self
*/
public function setDataNascimento($dataNascimento) {
    $this->dataNascimento = $dataNascimento;

    return $this;
}

/**
* Get the value of Telefone
*
* @return mixed
*/
public function getTelefone() {
   return $this->telefone;
}

/**
* Set the value of Telefone
*
* @param mixed telefone
*
* @return self
*/
public function setTelefone($telefone) {
    $this->telefone = $telefone;

    return $this;
}

/**
* Get the value of Id Usuario
*
* @return mixed
*/
public function getIdUsuario() {
   return $this->idUsuario;
}

/**
* Set the value of Id Usuario
*
* @param mixed idUsuario
*
* @return self
*/
public function setIdUsuario($idUsuario) {
    $this->idUsuario = $idUsuario;

    return $this;
}

}
