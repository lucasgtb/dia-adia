$(document).on('ready', function() {
    // var hostname = window.location.href;
    // hostname = hostname.split('home');
    $('#loginForm').validate({
        rules: {
            login: {
                required: true,
            },
            senha: {
                required: true,
                minlength: 6
            }
        },
        messages: {
            plataforma: {
                required: "Por favor, selecionar a plataforma.",
            },
            login: {
                required: "Por favor, informe seu Login.",
            },
            senha: {
                required: "Por favor, insira sua Senha.",
                minlength: jQuery.validator.format("Sua senha deve conter ao menos {0} caracteres.")
            }
        },

        submitHandler: function(form) {
            $.post(host + '/login',
            {
                login: $(form).find("input[name='login']").val(),
                senha: $(form).find("input[name='senha']").val()
            },
            function(data) {

                if (data == 404) {
                    $(form).find("input[name='senha']").removeClass('valid')
                    $(form).find("input[name='senha']").addClass('error');
                    $(form).find(".group-senha").append('<label id="senha-error" class="error" for="senha">Login ou senha inválidos.</label>');
                    $(form).find("#senha-error").show();
                } else if (data == 201) {

                    $(form).find("input[name='senha']").removeClass('valid')
                    $(form).find("input[name='senha']").addClass('error');
                    $(form).find(".group-senha").append('<label id="senha-error" class="error" for="senha">Esse usuário consta como bloqueado favor entre em contato com o suporte.</label>');
                    $(form).find("#senha-error").show();

                } else if (data == 200) {
                    window.location.href = host + "/inicio";
                } else if (data == 401) {
                    window.location.href = 'bloqueio';
                }
            });
        }
    });

    $('#url').on('change', function () {
        $('#loginForm').attr('action', url);
        $('#painel').val($('#url option:selected').attr('id') );
    });
});
