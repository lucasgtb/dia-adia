<?php

use App\App;
use App\Lib\Erro;


error_reporting(E_ALL & ~E_NOTICE);

setlocale(LC_TIME, 'portuguese');
date_default_timezone_set('America/Sao_Paulo');

require_once("vendor/autoload.php");
session_start();

try {
    $app = new App();
    $app->run();
}catch (\Exception $e){
    $oError = new Erro($e);
    $oError->render();
}
